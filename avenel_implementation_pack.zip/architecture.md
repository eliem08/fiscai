# AVENEL --- Master System Architecture

**Version:** 1.0 \| **Date:** 30 October 2026 \| **Status:** Proposed
baseline

> **Product thesis:** AVENEL sells completed financial operations.
> Software, AI agents, deterministic accounting controls, integrations,
> and human review are the delivery engine.

## 0. Purpose and scope

This document defines the target architecture for AVENEL, an AI-powered
financial operations company initially serving Moroccan accounting firms
(*fiduciaires*). AVENEL receives financial documents and data, executes
bounded accounting workflows, prepares evidence-backed outputs, and
routes exceptions and approval-required decisions to qualified
professionals.

### 0.1 Business lines

1.  **AVENEL Services --- Service as Software (SaS):** completed
    bookkeeping and financial workflows, initially monthly
    accounting-file preparation.
2.  **AVENEL Agents --- AI workforce:** specialised, permission-bounded
    agents that execute defined operational tasks.
3.  **AVENEL API --- Financial operations infrastructure:** capabilities
    exposed to approved accounting platforms, fintechs, banks, ERP
    providers, and partners.
4.  **Operations Console:** firm and internal control surfaces for
    submitting work, monitoring progress, reviewing evidence, resolving
    exceptions, and approving deliverables. This is not the core value
    proposition.

### 0.2 Principles

-   Outcome-first: model the product around completed work, not screens
    or seats.
-   Workflow before agents: durable workflows control execution; agents
    perform bounded steps.
-   Deterministic core: arithmetic, posting constraints, permissions,
    validation, and state transitions use deterministic code wherever
    possible.
-   AI proposes and interprets; it does not become the authoritative
    ledger or silently commit high-impact decisions.
-   Human accountability: professional judgement, uncertain cases, tax
    decisions, and regulated actions require an appropriately authorised
    human.
-   Evidence by default: every material output traces to sources,
    transformations, rules, model versions, and approvals.
-   Tenant isolation across databases, object storage, queues, caches,
    search, logs, and analytics.
-   Country-aware architecture: jurisdiction-specific behaviour is
    delivered through versioned country packs, not hardcoded prompts.
-   Progressive autonomy: autonomy is earned per task through
    evaluation, policy, and customer approval.
-   Replaceable providers: OCR, LLM, cloud, and accounting integrations
    sit behind adapters.
-   Human review is an exception and approval mechanism, not hidden
    manual outsourcing.
-   Security, privacy, and regulatory validation are product
    requirements.

This is a target architecture, not evidence that the system is already
built, compliant, certified, or production-ready. Moroccan legal,
accounting, tax, data-protection, professional-practice, hosting, and
cross-border transfer requirements require qualified local review.

## 1. Product scope

### 1.1 Initial workflow: monthly bookkeeping preparation

**Inputs** - Supplier/customer invoices, receipts, credit notes, expense
documents. - Bank statements and transaction exports. - Client
explanations and missing-document responses. - Prior-period balances and
approved accounting context. - Customer chart of accounts, tax mappings,
and accounting policies.

**Outputs** - Structured document register and extracted fields. -
Duplicate, anomaly, missing-document, and validation report. - Proposed
accounting entries with source evidence. - Bank transaction matches and
reconciliation report. - Unresolved-items queue. - Review-ready
accounting file. - Export package for the firm's accounting system. -
Evidence and approval history.

Proposed entries are not final posted entries unless an authorised
professional explicitly approves them and the destination integration
supports a controlled posting operation.

### 1.2 Capability scope

  Capability                                            MVP                                  Later
  ----------------------------------------- --------------- --------------------------------------
  Firm, user, client-entity onboarding                  Yes 
  Secure document intake and validation                 Yes 
  OCR/layout extraction and normalisation               Yes 
  Classification and duplicate detection                Yes 
  Customer-specific account mapping                     Yes 
  Proposed bookkeeping entries                          Yes 
  Bank transaction import and matching                  Yes 
  Exceptions, missing-document handling                 Yes 
  Human review and approval                             Yes 
  Evidence-backed export package                        Yes 
  Client chasing and monthly close                    Basic                               Advanced
  Direct accounting-system posting            Limited pilot                               Expanded
  Tax preparation and payroll preparation                                         Human-supervised
  Partner APIs and multi-country packs                                                         Yes
  Direct SME service channel                                                                 Later
  AI-native accounting firm                                   Only after legal/professional design

### 1.3 MVP exclusions

No autonomous tax filing, payroll payment, bank transfer, unreviewed
final posting, generic unrestricted agent, legal/tax advice,
multi-country tax logic, unconstrained agent delegation, or full
ERP/general-ledger replacement. Do not train foundation models on
customer documents by default.

## 2. Actors, organisations, and tenancy

### 2.1 Actors

-   Platform administrator: global configuration, approved providers,
    service health.
-   AVENEL operations specialist: monitors service delivery and resolves
    permitted operational exceptions.
-   Firm owner/partner: tenant owner, client portfolio, service plan,
    approval policy.
-   Firm manager: allocates work and supervises staff.
-   Accountant/bookkeeper: reviews proposals, resolves accounting
    exceptions, approves within authority.
-   Firm staff: submits documents and manages assigned work.
-   Client business user: uploads documents, answers requests, views
    permitted status/output.
-   Partner API client: approved external platform.
-   Auditor/read-only reviewer: access to specifically authorised
    evidence.

### 2.2 Tenancy hierarchy

``` mermaid
flowchart TD
  P[AVENEL Platform] --> A[Tenant: Accounting Firm A]
  P --> B[Tenant: Accounting Firm B]
  A --> U1[Users and roles]
  A --> C1[Client entity 1]
  A --> C2[Client entity 2]
  B --> U2[Users and roles]
  B --> C3[Client entity 3]
  C1 --> W1[Periods and workflows]
  C2 --> W2[Periods and workflows]
  C3 --> W3[Periods and workflows]
```

A tenant is normally an accounting firm; a client entity is a business
served by that firm. Users access a tenant only through explicit
membership. Client users are restricted to their own entity and
permitted actions.

### 2.3 Isolation requirements

-   Every tenant-owned row has a tenant identifier.
-   Tenant context is resolved from authenticated membership, never
    trusted from a caller-supplied ID alone.
-   Use PostgreSQL row-level security as defence in depth where
    practical.
-   Object storage, queues, search, vector retrieval, caches, exports,
    and analytics preserve tenant scope.
-   Workers re-check tenant/resource permissions before actions.
-   Cross-tenant access tests are release blockers.
-   Support access is purpose-bound, time-limited, least-privilege, and
    audited.

## 3. System context and logical architecture

``` mermaid
flowchart LR
  Firm[Firm users] --> Console[Operations console]
  Client[Client users] --> Portal[Client portal]
  Partner[Partner platforms] --> API[Partner API]
  Console --> Core[AVENEL financial operations platform]
  Portal --> Core
  API --> Core
  Core <--> ERP[Accounting / ERP systems]
  Core <--> Bank[Approved bank data sources]
  Core <--> Mail[Email and document channels]
  Core <--> Store[Encrypted object storage]
  Core <--> AI[Approved OCR / AI providers]
  Core --> Review[Authorised human reviewers]
```

``` mermaid
flowchart TB
  subgraph Experience
    Web[Firm console]
    Portal[Client portal]
    PartnerAPI[Partner API]
  end
  subgraph Edge
    Gateway[API gateway / BFF]
    Identity[Identity, MFA, RBAC / ABAC]
  end
  subgraph Domain
    Org[Organisation and client registry]
    Work[Work management]
    Docs[Document management]
    Books[Accounting preparation]
    Recon[Reconciliation]
    Exceptions[Exceptions and approvals]
    Billing[Usage and billing]
    Connectors[Integration hub]
  end
  subgraph Execution
    Orchestrator[Durable workflow engine]
    Queue[Task queues]
    Runtime[Agent runtime]
    ToolGate[Permissioned tool gateway]
    Rules[Rules and policy engine]
    Human[Human review queue]
  end
  subgraph Data
    DB[(PostgreSQL)]
    Objects[(Object storage)]
    Search[(Search index)]
    Evidence[(Append-only evidence / audit)]
    Analytics[(Operational analytics)]
  end
  Web --> Gateway
  Portal --> Gateway
  PartnerAPI --> Gateway
  Gateway --> Identity --> Domain
  Domain --> Orchestrator
  Orchestrator --> Queue --> Runtime
  Runtime --> ToolGate --> Rules
  Orchestrator <--> Human
  Domain <--> DB
  Docs <--> Objects
  Domain <--> Search
  Orchestrator --> Evidence
  Domain --> Analytics
  Connectors <--> ERP[ERP / accounting]
  Connectors <--> Mail[Email]
  Connectors <--> Bank[Bank sources]
  Runtime --> AI[OCR / LLM providers]
```

### 3.1 Layers

1.  Experience: firm console, client portal, internal operations
    surface, partner API.
2.  Edge and identity: authentication, authorisation, tenant resolution,
    request validation, rate limits.
3.  Domain: organisations, periods, documents, bookkeeping,
    reconciliation, approvals, billing.
4.  Workflow control plane: durable state machines, retries, deadlines,
    escalations, compensation.
5.  AI execution plane: agent runtime, model gateway, tool gateway,
    prompt/version registry, evaluations.
6.  Deterministic accounting plane: chart-of-account mapping,
    validation, arithmetic, reconciliation and jurisdiction rules.
7.  Data/evidence plane: relational records, encrypted files, audit
    events, provenance, search.
8.  Integration plane: accounting systems, email, file import/export,
    bank data sources, partner APIs.
9.  Operations/governance: monitoring, quality assurance, security, cost
    controls, support, incident response.

## 4. Recommended implementation stack

  --------------------------------------------------------------------------
  Layer                   Baseline                   Notes
  ----------------------- -------------------------- -----------------------
  Web                     Next.js + TypeScript       Firm and client
                                                     experience

  API                     Python + FastAPI           Typed domain API and AI
                                                     ecosystem

  Database                PostgreSQL                 Transactions,
                                                     relational integrity,
                                                     JSON, RLS

  Files                   S3-compatible encrypted    Originals, derivatives,
                          object storage             exports

  Workflow                Temporal or equivalent     Long-running workflows,
                          durable engine             recovery, timers

  Cache                   Redis where justified      Never source of truth

  OCR                     Provider adapter           Replaceable document
                                                     intelligence

  LLM                     Model gateway/provider     Routing, cost, privacy,
                          abstraction                versioning

  Search                  PostgreSQL initially;      Tenant-scoped search
                          dedicated later            

  Vector retrieval        Optional                   Approved knowledge
                                                     only, never ledger
                                                     truth

  Observability           OpenTelemetry-compatible   Traces, metrics,
                                                     structured logs

  Deployment              Containers and managed     Avoid premature
                          services                   platform complexity

  CI/CD                   GitHub Actions or          Tests, scans, release
                          equivalent                 gates

  Secrets                 Cloud secret manager/KMS   Key rotation and scoped
                                                     credentials
  --------------------------------------------------------------------------

Start as a **modular monolith** for domain APIs plus separate
workflow/worker processes. Extract services only when independent
scaling, security boundaries, ownership, or reliability justify it.
Avoid microservices for every domain at MVP.

## 5. Domain boundaries

-   **Identity & Access:** users, memberships, roles, permissions,
    service identities, MFA.
-   **Tenant & Organisation:** firms, client entities, identifiers,
    jurisdiction, settings.
-   **Engagement & Work:** service agreement, work request, accounting
    period, SLA, status.
-   **Document Management:** upload, validation, classification,
    extraction, versioning, retention.
-   **Accounting Preparation:** chart of accounts, counterparties, tax
    codes, proposals, journal lines.
-   **Reconciliation:** bank imports, normalisation, matches, unmatched
    items.
-   **Workflow Orchestration:** definitions, executions, tasks, timers,
    retries, escalations.
-   **Agent Governance:** agent versions, policies, tool permissions,
    model calls, evaluations.
-   **Review & Approval:** assignments, decisions, overrides, approval
    limits.
-   **Evidence & Audit:** provenance, event history, approvals, export
    manifests.
-   **Integration Hub:** connectors, credentials, sync cursors,
    webhooks, imports/exports.
-   **Billing & Entitlements:** plans, usage, limits, credits, partner
    usage.
-   **Quality & Analytics:** accuracy, exceptions, human effort, unit
    economics.
-   **Jurisdiction Packs:** country-specific rules, mappings, document
    requirements, effective dates.

Domain modules own their data and invariants. Agents never access
arbitrary tables. Workflow invokes domain commands. Integrations
translate external formats into canonical contracts. Analytics is
read-only relative to accounting truth.

## 6. End-to-end workflow: monthly bookkeeping preparation

``` mermaid
flowchart TD
  A[Create monthly work request] --> B[Collect documents and data]
  B --> C[Validate type, size, tenant, malware]
  C --> D[Store immutable source and hash]
  D --> E[Classify and extract]
  E --> F[Validate extracted fields]
  F --> G{Sufficient quality?}
  G -- No --> H[Exception / request information]
  H --> B
  G -- Yes --> I[Duplicate and related-document checks]
  I --> J[Map to customer accounting context]
  J --> K[Generate proposed entries]
  K --> L[Import and normalise bank transactions]
  L --> M[Reconcile]
  M --> N[Deterministic QA]
  N --> O{Exception or approval required?}
  O -- Yes --> P[Human review]
  P --> N
  O -- No --> Q[Prepare deliverable and evidence]
  Q --> R[Accountant approval]
  R --> S[Export / handoff]
  S --> T[Complete and record outcome]
```

Suggested work-request states: `draft`, `submitted`,
`awaiting_documents`, `ingesting`, `processing`,
`awaiting_client_response`, `awaiting_internal_review`,
`awaiting_accountant_approval`, `ready_for_export`, `exporting`,
`completed`, `completed_with_exceptions`, `failed`, `cancelled`.

State transitions are enforced by domain logic; users and agents cannot
arbitrarily mark work completed. Each workflow pins its definition,
accounting-context version, and jurisdiction-pack version. Retries are
bounded and idempotent. Human tasks have an assignee/queue, due date,
required permission, reason, and escalation. Reprocessing creates a new
execution/revision; it never silently overwrites an approved result.
External side effects use idempotency keys and outbox/inbox patterns.

## 7. AI workforce and agent architecture

### 7.1 Initial agents

  ------------------------------------------------------------------------------------
  Agent             Responsibility    Output                  Escalate when
  ----------------- ----------------- ----------------------- ------------------------
  Document Intake   Validate,         Metadata, document      Ambiguous identity,
                    classify, group,  type, missing-file      unsupported/suspicious
                    register          signal                  file

  Extraction        Read invoice,     Structured candidate    Low confidence,
                    receipt, bank     fields with page/region conflict, illegible
                    fields            evidence                source

  Bookkeeping       Propose           Draft entries and       Unmapped account,
  Preparation       account/tax       rationale               unusual treatment,
                    mapping and                               uncertain tax
                    journal lines                             

  Reconciliation    Suggest           Match candidates and    Ambiguous match or
                    transaction       differences             material discrepancy
                    matches                                   

  Client            Draft/send        Message drafts or       Dispute, legal/tax
  Communication     approved requests approved-template sends question, unusual
                                                              request

  Quality Control   Check             Findings, severity,     Critical error, missing
                    completeness and  release recommendation  evidence, policy breach
                    policy                                    

  Reporting         Summarise period  Draft                   Unsupported conclusion
                    and unresolved    operational/financial   or judgement
                    work              summaries               
  ------------------------------------------------------------------------------------

### 7.2 Agent contract and controls

Every invocation carries server-resolved tenant/workflow/task identity,
agent and prompt version, jurisdiction and accounting-context versions,
approved input references, allowed tool scopes, deadline, and
model/token/cost budgets. Responses are typed and schema-validated and
include status, proposals, evidence references, warnings, confidence,
reason codes, and whether human review is required.

Controls: - No unrestricted database, shell, browser, or network
access. - Tools are allow-listed by agent, task, tenant, and resource. -
Read and write scopes are separate. - High-impact tools require approval
or a short-lived approval token. - Tool inputs/outputs are validated and
logged. - Secrets never enter prompts. - Retrieved documents are
untrusted data, not instructions; prompt injection cannot alter system
policy or tool permissions. - Model calls have timeouts, budgets, rate
limits, provider controls, and approved fallbacks. - Record
provider/model, model config, prompt version, latency, usage, cost, and
safety result, subject to privacy rules. - Agents cannot approve their
own high-impact outputs. - Model/prompt changes require regression
evaluation before release.

### 7.3 Autonomy tiers

  -----------------------------------------------------------------------
  Tier                    Behaviour               Example
  ----------------------- ----------------------- -----------------------
  0 --- Assist            Suggest only            Draft an accounting
                                                  entry

  1 --- Prepare           Execute reversible      Classify and register
                          preparation             document

  2 --- Controlled        Execute low-risk action Send approved
                          under policy            missing-document
                                                  reminder

  3 --- Approval-gated    Prepare high-impact     Export approved journal
                          action; human           batch
                          authorises              

  4 --- Restricted        Mature low-risk task    Routine matching within
  autonomy                under strict monitoring validated thresholds
  -----------------------------------------------------------------------

Autonomy is configured by task, customer, jurisdiction, materiality,
confidence, and risk---not globally.

## 8. Canonical accounting data model

AVENEL maintains a canonical operational accounting model; it does not
claim to replace the customer's authoritative general ledger.

### 8.1 Core entities

  -----------------------------------------------------------------------
  Entity                              Purpose / key fields
  ----------------------------------- -----------------------------------
  Tenant                              Accounting firm workspace, legal
                                      name, settings, status

  User / Membership                   Identity, tenant, role,
                                      permissions, MFA

  ClientEntity                        Business served, identifiers,
                                      jurisdiction

  Engagement                          Service relationship, scope, status

  AccountingPeriod                    Period dates, status, context
                                      version

  WorkRequest                         Service type, period, SLA, status

  Document / DocumentVersion          Logical document; immutable file
                                      version, object key, hash, MIME,
                                      size

  Extraction                          Candidate fields, schema version,
                                      confidence, evidence locations

  Counterparty                        Supplier/customer identity,
                                      identifiers, aliases

  ChartOfAccount                      Customer-specific account code,
                                      label, type, active state

  TaxCode                             Customer/jurisdiction mapping,
                                      treatment, effective dates

  JournalProposal / JournalLine       Draft accounting operation and
                                      debit/credit lines

  BankAccount / BankTransaction       Masked account reference and
                                      normalised transaction

  ReconciliationMatch                 Candidate/approved match, score,
                                      status

  Exception                           Issue code, severity, owner, due
                                      date, resolution

  Approval                            Actor, decision, scope, rationale,
                                      timestamp

  Evidence                            Source/derived references, hashes,
                                      lineage relation

  WorkflowExecution / AgentInvocation Definition and execution records,
                                      agent version, inputs, outputs,
                                      metrics

  IntegrationConnection               Provider, encrypted credential
                                      reference, scopes

  ExportBatch                         Destination, payload hash, status,
                                      idempotency key

  UsageRecord                         Billable unit, quantity, price
                                      version, workflow reference

  AuditEvent                          Actor, action, resource, timestamp,
                                      metadata
  -----------------------------------------------------------------------

### 8.2 Accounting invariants

-   Use fixed-precision decimal types, never binary floating point, for
    money.
-   Currency is explicit on all monetary values.
-   Debit and credit totals balance before a proposal can be approved
    for export.
-   Periods, chart mappings, and jurisdiction rules are versioned.
-   Source documents are immutable; corrections create new versions or
    annotations.
-   Every proposed entry links to source documents and extraction
    evidence.
-   Tax treatment uses explicit versioned rules and/or human approval;
    an LLM proposal is not authoritative.
-   An AVENEL proposal is not "posted" merely because it exists.
-   Corrections and reversals are explicit; approved history is not
    silently edited.
-   Manual overrides record actor, old/new value, reason, and timestamp.
-   Rounding, dates, time zones, fiscal periods, and currency
    conversions are explicit.

## 9. Document intelligence and evidence lineage

Document pipeline: 1. Receive through portal, controlled upload,
approved email channel, or API. 2. Authenticate uploader and resolve
tenant/client entity. 3. Validate file type, MIME, size, checksum, and
policy; malware-scan/quarantine. 4. Store original encrypted and
calculate cryptographic hash. 5. Create logical document and immutable
version. 6. Route to OCR/layout extraction. 7. Extract fields with
page/region/text-span and confidence evidence. 8. Normalise values while
retaining originals. 9. Run deterministic validation and duplicate
checks. 10. Request human correction/client clarification when needed.
11. Link document to proposals, transactions, exceptions, and exports.

``` mermaid
flowchart LR
  Source[Original document] --> Version[Immutable version + hash]
  Version --> Extract[Extraction with locations]
  Extract --> Validate[Normalisation and validation]
  Validate --> Proposal[Accounting proposal]
  Proposal --> Review[Human review / override]
  Review --> Export[Export batch]
```

Evidence must retain source hash, field/page location where available,
OCR/model provider and version, transformations, ruleset and
jurisdiction version, agent/prompt version, human corrections and
approvals, and export payload hash/destination. A reviewer must navigate
from a journal line to its supporting source and understand how the
proposal was produced.

Files are encrypted in transit and at rest; originals remain immutable;
downloads use short-lived scoped links. Sensitive content is excluded
from ordinary logs. Retention applies to originals, derivatives,
extracted text, indexes, embeddings, backups, and exports.

## 10. Rules engine and jurisdiction packs

Use deterministic code/configuration for arithmetic, balancing,
duplicate checks, required fields, date/period constraints, permissions,
approval thresholds, reconciliation tolerances, tax-code eligibility
where formally encoded, and export validation.

Use AI for unstructured reading, classification, candidate mappings,
match explanations, client-message drafts, and summaries. AI can
propose; approved rules and human decisions determine authoritative
outcomes.

A jurisdiction pack is a versioned, tested module containing
country/effective dates, accounting framework references, chart
mappings, tax codes/validation, required document types/fields, invoice
rules, rounding/currency conventions, fiscal calendar, export formats,
terminology/language, test suite, source references, and accountable
reviewer/approval date.

The first pack is Morocco-focused and validated by Moroccan accounting
professionals. Tax rules are tied to the applicable tax year and
official guidance. Do not hardcode tax rates into prompts. Changes to
law, guidance, or practice trigger a formal version and review process.
A pack is not itself proof of legal compliance.

## 11. Integration architecture

All external systems connect through adapters and canonical internal
contracts. Every connector has explicit scopes, encrypted credentials,
sync state/cursor, rate limits, error handling, and health status.
Imports/exports are idempotent; webhooks are authenticated,
deduplicated, and replay-protected. Manual import/export remains
available during MVP.

Priority order: 1. CSV/XLSX and standard document uploads. 2. Bank
statement imports from supported files. 3. Controlled email intake. 4.
Export to the accounting systems used by pilot firms. 5. Partner API and
webhooks after internal contracts stabilise.

Do not assume every Moroccan accounting product exposes an API; validate
technical and contractual feasibility for each connector.

Standard connector capabilities, where supported: `authenticate`,
`test_connection`, `discover_capabilities`, `import_documents`,
`import_bank_transactions`, `export_approved_batch`,
`get_export_status`, `receive_webhook`, `reconcile_sync_state`,
`disconnect_and_revoke`.

Unsupported capabilities must be declared rather than simulated.
Credentials are never exposed to agents or frontend clients.

## 12. API architecture

API surfaces: - Internal domain API for service-to-service commands and
queries. - Customer API for tenant-scoped firm operations. - Partner API
for approved third parties. - Webhook API for outbound events and
inbound provider callbacks.

Illustrative resources:

``` http
POST   /v1/client-entities
GET    /v1/client-entities/{id}
POST   /v1/work-requests
GET    /v1/work-requests/{id}
POST   /v1/work-requests/{id}/documents
GET    /v1/documents/{id}
GET    /v1/documents/{id}/extractions
GET    /v1/work-requests/{id}/exceptions
POST   /v1/exceptions/{id}/resolve
GET    /v1/work-requests/{id}/proposals
POST   /v1/proposals/{id}/submit-for-review
POST   /v1/approvals/{id}/decision
POST   /v1/export-batches
GET    /v1/export-batches/{id}
GET    /v1/usage
```

Standards: version APIs; publish OpenAPI; OAuth 2.0/OIDC for
user/partner access; scoped service credentials for machine clients;
idempotency keys for side effects; pagination/filtering; stable errors;
request/correlation IDs; rate limits; boundary validation; opaque public
IDs where appropriate. Never trust caller-supplied tenant identity.
Webhooks use signatures, timestamps, delivery IDs, retries, and replay
protection. Event payloads contain minimum necessary data, not sensitive
document content by default.

## 13. Human review and approval

The review queue is a first-class capability. Prioritise by severity,
materiality, confidence, deadline, and SLA. Each task shows what needs a
decision, why it escalated, source evidence, agent proposal/rationale,
deterministic checks, options/consequences, reviewer authority, and
decision history.

Approval policies are configurable by action, tenant, jurisdiction,
amount/materiality, confidence, exception severity, role, reversibility,
and destination. No agent approves its own high-impact output. Support
separation of duties.

Corrections may inform future rules/evaluations only through controlled
change: record correction/source, distinguish one-off from policy,
obtain permission for reuse, version context, test proposed changes, and
never silently learn from one override.

## 14. Security, privacy, and compliance

### 14.1 Controls

-   OIDC identity, MFA for privileged roles, RBAC plus
    resource/attribute checks.
-   Least-privilege service identities and just-in-time admin elevation.
-   Encryption in transit/at rest, managed keys, rotation, secrets
    manager.
-   Tenant isolation across all data planes.
-   Malware scanning, secure file handling, WAF, rate limiting, input
    validation.
-   Tamper-evident audit for critical events.
-   Dependency/container/code scanning and patch management.
-   Backups, restore tests, disaster recovery, incident response.
-   Access reviews, time-bound support access, break-glass logging.

### 14.2 Privacy

Document purpose and lawful basis with counsel; define
controller/processor roles; maintain data inventory, data-flow map,
subprocessors and processing terms; set retention by data class; support
applicable access/correction/export/deletion requests; review
international transfers and provider locations; separate production from
development; use synthetic or anonymised test data. Customer data is not
used for model-provider training absent a separate explicit lawful
arrangement. Minimise/redact before external model calls where feasible.

### 14.3 Morocco validation checklist

Obtain qualified local advice on Law 09-08 and CNDP obligations
(including required declarations/authorisations), international
transfers, controller/processor contracts, professional rules for
accounting/bookkeeping/tax preparation/filing, Moroccan accounting and
tax rules by year, retention/evidence requirements,
hosting/cybersecurity obligations, and whether planned activities
require qualified professional involvement. This is a checklist, not
legal advice or a compliance claim.

### 14.4 Threat model

  -----------------------------------------------------------------------
  Threat                              Mitigation
  ----------------------------------- -----------------------------------
  Cross-tenant exposure               Server-resolved tenant context,
                                      RLS, storage policies, isolation
                                      tests

  Prompt injection in documents       Treat content as untrusted; tools
                                      allow-listed; policy outside prompt

  Fraudulent/altered invoice          Provenance, duplicate/anomaly
                                      checks, human review

  Credential theft                    Secret manager, narrow scopes,
                                      rotation, revocation

  Agent misuse                        Tool gateway, action policy,
                                      approval gates

  Data exfiltration in logs/model     Redaction, minimisation, provider
  calls                               controls

  Replay/duplicate export             Idempotency, outbox/inbox,
                                      destination reconciliation

  Insider misuse                      Least privilege, access logs,
                                      time-bound support

  Model regression                    Golden evaluations, canary release,
                                      rollback

  Ransomware/data loss                Immutable backups, restore drills,
                                      incident plan
  -----------------------------------------------------------------------

## 15. Data, eventing, and retention

Storage responsibilities: - PostgreSQL: authoritative business records,
permissions, workflow state, proposals, approvals, integration state. -
Object storage: originals, derivatives, export packages. - Search:
tenant-scoped document metadata and approved text. - Vector index:
optional, tenant-scoped approved knowledge; never accounting truth. -
Evidence/audit: append-only critical provenance and events. - Analytics:
minimised operational/commercial aggregates.

Domain events include `document.received`, `document.extracted`,
`document.needs_review`, `work_request.processing_started`,
`journal_proposal.created`, `reconciliation.match_proposed`,
`exception.created`, `approval.granted`, `export.completed`, and
`work_request.completed`. Use transactional outbox; consumers are
idempotent; event schemas are versioned.

Define retention for originals, extracted text/derivatives,
proposals/exports, audit/approval records, model
prompts/responses/telemetry, backups, communications, and credentials.
Deletion propagates to derivatives and indexes where legally
permissible, while preserving records that must be retained. Support
legal holds and deletion exceptions.

## 16. Observability and quality

Measure three dimensions: 1. Technical: availability, latency, errors,
queue depth, worker/provider health. 2. Workflow: time in each state,
retries, blocked work, escalations, SLA breaches. 3. Business quality:
extraction accuracy, accepted proposal rate, match precision, exception
rate, human minutes/file, cost/file, margin.

Every workflow has a correlation ID linking API, workflow, task,
agent/tool/model calls, evidence, human review, integrations,
deliverable, and billing. Use structured redacted logs; never log
sensitive document contents.

Quality metrics by task, customer, document type, jurisdiction, and
model/workflow version: - extraction precision/recall at field level; -
classification and duplicate-detection accuracy; - proposed-entry
acceptance and correction rates; - reconciliation precision/recall; -
false positive/negative exception rates; - critical error rate; - human
intervention and review minutes per file; - rework and on-time
completion rates.

Commercial metrics: files/month, revenue/file and per tenant, variable
OCR/model/compute cost, human operations cost, gross margin, CAC,
retention/expansion, onboarding time, customer capacity gained, API
usage and partner concentration.

Pilot hypotheses (not market benchmarks): 40% processing-time reduction;
98% accuracy on agreed critical fields; 90% correct initial
classification; 80% acceptance of proposed entries without substantive
correction; zero cross-tenant exposure; declining human minutes per
file. Establish baseline and labelled evaluation before setting release
thresholds. Never improve acceptance metrics by hiding errors or
reducing review quality.

## 17. Reliability and failure handling

Use durable workflows, bounded exponential retries with jitter,
dead-letter handling, typed error classes, provider timeouts/circuit
breakers, immutable inputs, safe reprocessing, transactional domain
changes, outbox/inbox integration, human recovery for stuck workflows,
tested backups, and explicit incomplete/failed states. Define RTO/RPO
after customer and legal requirements are known.

  -----------------------------------------------------------------------
  Failure                             Expected behaviour
  ----------------------------------- -----------------------------------
  OCR unavailable                     Queue/retry; preserve source;
                                      expose delay

  LLM unavailable                     Approved equivalent fallback or
                                      safe pause

  Accounting system unavailable       Keep export pending; retry
                                      idempotently

  Duplicate upload                    Link or flag; do not silently
                                      discard

  Invalid model output                Schema reject; bounded retry or
                                      review

  Review overdue                      Escalate; never auto-approve

  Worker crash                        Resume without duplicating side
                                      effects

  Integration revoked                 Stop actions; mark workflows
                                      blocked

  Suspected breach                    Contain, preserve evidence, invoke
                                      incident plan
  -----------------------------------------------------------------------

## 18. Deployment architecture

Environments: local (synthetic fixtures), CI (ephemeral, no production
data), development (synthetic), staging (production-like,
masked/anonymised), production (strict access, monitored releases,
backups).

Initial topology: frontend, API, workflow engine, worker pools,
PostgreSQL, encrypted object storage, optional Redis, observability,
secrets/KMS. Scale worker pools independently by OCR, model,
reconciliation, and export workload. Public ingress only through WAF/API
gateway; databases and internal services remain private. Restrict worker
egress to approved providers/connectors. Separate production credentials
and use private service identities.

## 19. Testing and AI evaluation

Test pyramid: 1. Unit: calculations, validation, mappings, state
transitions, permissions. 2. Contract: APIs, adapters, events, agent
schemas. 3. Integration: database, storage, workflow engine, providers.
4. Workflow: complete file lifecycle, retry, approval, cancel,
reprocess. 5. Security: tenant isolation, upload, injection, secret
exposure. 6. AI evaluations: extraction, classification, matching,
proposal quality, escalation. 7. End-to-end: firm/client journeys. 8.
Operations: restore, provider outage, queue saturation, worker crash,
incident drills.

Build a permissioned golden dataset covering clean/poor scans,
languages/layouts, duplicates, credit notes, missing/conflicting fields,
unusual dates/currencies, ambiguous bank descriptions, adversarial
document instructions, and pilot-identified edge cases. Use lawful,
synthetic, or anonymised data. Label expected outputs and
reviewer/version.

Release gates: contracts and tests pass; golden metrics meet task
thresholds; critical regressions and tenant isolation pass; escalation
works; cost/latency fit budgets; rollback exists; accountable reviewer
approves.

## 20. Billing and unit economics

AVENEL charges for verified delivered work, not simply agent
invocations. Possible units: completed monthly accounting file,
document-volume tier, reconciliation batch, workflow package, partner
API usage, enterprise commitment. Start with a simple offer firms can
compare to current labour costs.

Usage records include tenant/client, service SKU and price version,
workflow/period, quantity, completion status, included/billable tasks,
credits/rework, and internal compute/OCR/model costs. Failed/incomplete
workflows are not billable unless contract terms explicitly say
otherwise. Billing derives from verified workflow outcomes.

``` text
Gross profit per completed file
= Revenue per file
- Human operations cost
- OCR / model / compute cost
- Variable integration and storage cost
- Other directly attributable variable costs

Gross margin = Gross profit / Revenue
```

Track contribution margin by customer cohort and complexity. The model
is not scalable if review and exception labour rise linearly without a
path to reduce it.

## 21. Repository organisation and reusable assets

Recommended starting point is a modular monorepo. This is a proposed
target; audit existing repositories before merging or migrating code.

``` text
avenel/
├── apps/
│   ├── web/                 # Firm console and client portal
│   ├── api/                 # FastAPI domain API / BFF
│   ├── worker/              # Workflow and async workers
│   └── ops-console/         # Internal operations surface if separate
├── packages/
│   ├── contracts/           # OpenAPI, event and JSON schemas
│   ├── domain/              # Domain types and invariants
│   ├── accounting-core/     # Decimal arithmetic, journals, validation
│   ├── workflow-definitions/
│   ├── agent-runtime/
│   ├── tool-gateway/
│   ├── model-gateway/
│   ├── document-intelligence/
│   ├── evidence/
│   ├── integrations/
│   └── jurisdiction-packs/morocco/
├── infra/                   # Environments, containers, network, policies
├── migrations/
├── tests/                   # Unit, integration, workflow, security, evals
├── docs/                    # Architecture, ADRs, API, security, runbooks
├── scripts/
└── .github/workflows/
```

Previously discussed candidate assets: FiscAI, AgentTracer, AgentReplay,
AgentWarden, ToolGate, Data-Kondo. Potential roles inferred from their
names/context: accounting/financial domain functions; agent traces;
controlled replay; agent governance; permissioned tool execution; data
quality. These are candidates only. Audit actual code, licences,
security, dependencies, tests, and compatibility before reuse. Names do
not prove capabilities. Keep AVENEL contracts independent of legacy
repository structure.

## 22. Implementation roadmap

**Phase 0 --- Discovery:** 10--20 interviews across firm owners,
accountants, staff, and business clients; three design partners if
possible; map one real workflow; measure baseline
time/rework/errors/cost; obtain lawful sample data; validate
accounting-system integration; obtain legal/privacy input. Exit:
validated pain, pilot access, and willingness to pay or a clear
design-partner agreement.

**Phase 1 --- Secure foundation:** tenant/user/client model,
authentication/MFA/roles, isolation, secure upload/storage, document
register/hash, work request/period lifecycle, audit, CI/CD,
observability, backups, security tests. Exit: safe tenant-scoped
document intake and retrieval; isolation tests pass.

**Phase 2 --- End-to-end workflow:** OCR adapter,
extraction/classification/validation, chart configuration, bookkeeping
proposals, bank import/normalisation, reconciliation, deterministic QA,
human approval, evidence-backed export, manual export or one validated
connector. Exit: real pilot file reaches accountant-approved deliverable
with measured cost/time.

**Phase 3 --- Paid pilot:** client requests, SLA/escalation, QA
sampling, feedback, usage metering/invoicing, customer reporting,
replay/recovery. Exit: repeated paid use, acceptable quality, time
savings, improving unit economics.

**Phase 4 --- Expansion:** more connectors, monthly close, richer
portal, more agents, partner API, reporting, expanded Morocco pack.

**Phase 5 --- Internationalisation:** reviewed country packs, local
accounting/tax/language/document/integration adaptation, local
professional/legal validation, then expansion to SMEs and financial
institutions. Direct AI-native accounting services only after
professional/legal structure is established.

## 23. Architecture decision records

Create ADRs for: 1. Modular monolith and service extraction boundaries.
2. Cloud provider, hosting region, and residency. 3. Workflow engine. 4.
Identity provider and tenancy/RLS. 5. OCR provider and fallback. 6. LLM
routing, providers, and data terms. 7. Object storage, keys, retention,
legal holds. 8. First accounting export connector. 9. Morocco pack
ownership and approval. 10. Evidence/audit immutability. 11. Pricing
unit and service completion definition. 12. Human-review operating model
and professional responsibility. 13. Evaluation data use and model
improvement. 14. Partner API authentication and rate limits.

Each ADR records context, decision, alternatives, consequences,
security/privacy implications, owner, date, and review trigger.

## 24. Open questions before production

**Commercial:** Which exact workflow will pilot firms permit? What
defines a completed/billable file? Which exceptions are included? Who is
accountable approver?

**Accounting/localisation:** Which accounting framework and customer
policies apply? Which tax tasks are in/out of scope? Which mappings are
firm-specific? What retention/evidence rules apply?

**Technology/operations:** Which hosting region/provider? Which OCR/LLM
terms are acceptable? Which accounting connector is most valuable and
feasible? What volume/deadline is expected? What RTO/RPO/support hours
are needed?

**Governance:** Which materiality thresholds force review? Who may
approve/export/override? Which actions are reversible? What incident
notification duties apply? What data may be retained for evaluation?

## 25. MVP definition of done

The MVP is complete only when an authorised firm can: 1. Create/select a
client entity and accounting period. 2. Submit a real, permissioned
document set securely. 3. See validated, classified, extracted documents
with evidence. 4. Review duplicate, missing, and inconsistent
information. 5. Receive proposed entries linked to source evidence. 6.
Import bank transactions and inspect reconciliation proposals. 7.
Resolve exceptions or request missing information. 8. Have an authorised
accountant review and approve. 9. Export/download a structured,
traceable accounting package. 10. Inspect workflow history and
unresolved items. 11. Receive a transparent charge based on agreed
completed-work units. 12. Demonstrate measurable time/cost improvement
against baseline.

Tenant-isolation, access-control, audit, backup/restore, and
workflow-recovery tests are release blockers before live customer data.

## 26. North-star architecture test

For every feature ask:

> Does this help AVENEL deliver a more accurate, faster, lower-cost,
> more traceable completed financial operation---or does it merely add
> software surface area?

AVENEL is a governed execution system: canonical financial data,
deterministic rules, durable workflows, specialised AI workers, human
approval, integrations, and evidence. **The customer buys the completed
operation.**
