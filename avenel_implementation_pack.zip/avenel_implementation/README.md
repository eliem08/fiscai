# AVENEL implementation starter pack

Files:
- `implementation_spec.md` — full engineering specification and backlog.
- `avenel_implementation/db/migrations/001_initial_schema.sql` — initial PostgreSQL schema baseline.
- `avenel_implementation/contracts/openapi.yaml` — initial REST API contract.
- `avenel_implementation/workflows/monthly_bookkeeping_preparation.v1.yaml` — workflow definition and policies.
- `architecture.md` — parent system architecture.

Important: these are implementation baselines, not production-certified artefacts. Validate the SQL against the selected PostgreSQL version, add complete RLS policies and migration tests, lint the OpenAPI document, and implement the workflow using the selected durable workflow engine. Accounting and tax rules must be reviewed by qualified Moroccan professionals.
