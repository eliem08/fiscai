# AVENEL — Implementation-Ready Technical Specification
**Version:** 1.0  
**Date:** 30 October 2026  
**Status:** Engineering baseline — validate open decisions before production  
**Parent document:** `architecture.md`

> This specification converts AVENEL's target architecture into an implementable first release. It defines the MVP boundary, repository layout, database foundation, API contracts, workflow, agent/tool contracts, security requirements, tests, and engineering backlog. It does not certify legal or accounting compliance.

---

# 1. Engineering decisions and assumptions

## 1.1 Decisions to implement now

| Area | MVP decision | Why |
|---|---|---|
| Architecture | Modular monolith + separate workflow workers | Fast to build, clear domain boundaries, avoids premature microservices |
| Backend | Python + FastAPI | Typed API and mature data/AI ecosystem |
| Frontend | Next.js + TypeScript | Firm and client workspaces |
| Database | PostgreSQL | Transactional domain model and row-level security |
| ORM/migrations | SQLAlchemy 2.x + Alembic | Explicit migrations and typed persistence |
| Validation | Pydantic v2 | API, event, and agent schema validation |
| Workflow | Temporal (or equivalent durable engine) | Durable long-running workflows and retries |
| File storage | S3-compatible object storage | Encrypted originals, derivatives, and exports |
| AI access | Internal model gateway | Provider abstraction, budgets, logging, evaluation |
| OCR | Adapter interface; choose provider after pilot test | Avoid provider lock-in |
| Authentication | OIDC provider; MFA for privileged users | Standard identity and token validation |
| API style | REST + OpenAPI; webhooks later | Easy customer integration |
| Money | PostgreSQL `NUMERIC`, Python `Decimal` | No binary floating-point monetary calculations |
| Tenancy | Tenant-scoped rows + RLS + application authorisation | Defence in depth |
| Deployment | Containerised managed services | Keep operations tractable |
| Search | PostgreSQL full-text initially | Avoid extra infrastructure before justified |

## 1.2 Explicit assumptions

These are implementation assumptions, not validated customer or legal facts:

1. A customer tenant is usually an accounting firm.
2. Each tenant may manage multiple client entities.
3. The first paid workflow is monthly bookkeeping preparation.
4. AVENEL prepares proposals and evidence; an authorised professional approves the deliverable.
5. Initial import/export may be file-based if no stable accounting-system API is available.
6. The MVP is Morocco-first and initially supports MAD, but the data model must not hardcode a single currency.
7. Each pilot firm configures its own chart of accounts and mappings.
8. AVENEL is not the authoritative general ledger in the MVP.

## 1.3 Decisions blocked on validation

Do not hardcode these until validated:
- Moroccan account codes and tax treatment.
- Tax rates, deadlines, filing rules, and legal interpretations.
- Required retention periods and legal-hold rules.
- Whether a particular workflow constitutes a regulated professional service.
- First accounting-system connector.
- Hosting region and permitted data-transfer arrangements.
- Commercial definition of a billable completed file.
- SLA, materiality thresholds, and approval limits.

---

# 2. MVP functional boundary

## 2.1 Primary user journey

1. Firm administrator creates a client entity and accounting period.
2. Firm staff creates a monthly work request.
3. Staff uploads documents or imports a supported file.
4. AVENEL validates and stores original files.
5. Document pipeline classifies and extracts fields.
6. Deterministic validation and duplicate checks run.
7. Bookkeeping agent proposes accounting mappings and entries.
8. Bank statement import normalises transactions.
9. Reconciliation workflow proposes matches.
10. Quality controls identify missing information and exceptions.
11. Accountant reviews proposals and resolves exceptions.
12. Accountant approves the deliverable.
13. AVENEL creates an export package or sends it through an approved connector.
14. Workflow completes and a usage event is recorded.

## 2.2 MVP roles and permissions

| Capability | Firm owner | Manager | Accountant | Staff | Client user | AVENEL ops |
|---|---:|---:|---:|---:|---:|---:|
| Manage tenant settings | Yes | Limited | No | No | No | Platform-only |
| Invite firm users | Yes | Yes, if delegated | No | No | No | Support-only |
| Create client entity | Yes | Yes | Yes, if delegated | Limited | No | No |
| Upload documents | Yes | Yes | Yes | Yes | Own entity only | No, unless support-approved |
| View client documents | All tenant scope | Assigned scope | Assigned scope | Assigned scope | Own entity only | Time-bound support |
| Resolve operational exceptions | Yes | Yes | Yes | Limited | Respond only | Assigned queue |
| Approve accounting deliverable | Per policy | Per policy | Per authority | No by default | No | No |
| Configure integration | Yes | Delegated | No | No | No | Platform support |
| View billing/usage | Yes | Limited | No | No | No | Platform billing |
| Export approved work | Per policy | Per policy | Per authority | No by default | No | No |

The permission matrix must be configurable. The table is a starting policy, not a fixed legal allocation of professional authority.

## 2.3 Required screens

**Firm workspace**
- Overview: active work, blocked work, due dates, SLA, recent completions.
- Client entities: searchable list, status, assigned team.
- Client detail: profile, accounting settings, periods, documents, integrations.
- Work request detail: workflow timeline, documents, proposals, reconciliation, exceptions, approvals, export.
- Review queue: prioritised tasks and evidence.
- Integrations: connected systems, scopes, last sync, failures.
- Usage and billing: completed units, pending units, price version.
- Team and permissions: users, roles, invitations.

**Client portal**
- Upload documents.
- View requested/missing items.
- Respond to questions and attach supporting material.
- View permitted workflow status and completed deliverables.
- No access to internal agent reasoning, other clients, firm-only notes, or approval controls.

**Internal operations**
- Queue health and stuck workflows.
- Provider health and retry status.
- Customer support access with just-in-time approval.
- Quality sampling and exception trends.
- No unrestricted browsing of customer financial data.

---

# 3. Repository and module structure

Recommended monorepo:

```text
avenel/
├── apps/
│   ├── api/
│   │   ├── avenel_api/
│   │   │   ├── main.py
│   │   │   ├── dependencies/
│   │   │   ├── middleware/
│   │   │   └── routes/
│   │   └── tests/
│   ├── web/
│   │   ├── app/
│   │   ├── components/
│   │   ├── features/
│   │   └── lib/
│   ├── worker/
│   │   ├── activities/
│   │   ├── workflows/
│   │   └── workers/
│   └── ops-console/              # May be a role-restricted area of web initially
├── packages/
│   ├── domain/
│   │   ├── identity/
│   │   ├── tenants/
│   │   ├── clients/
│   │   ├── work/
│   │   ├── documents/
│   │   ├── accounting/
│   │   ├── reconciliation/
│   │   ├── approvals/
│   │   ├── evidence/
│   │   └── billing/
│   ├── contracts/
│   │   ├── api/
│   │   ├── events/
│   │   └── agents/
│   ├── agent_runtime/
│   ├── tool_gateway/
│   ├── model_gateway/
│   ├── document_intelligence/
│   ├── integrations/
│   │   ├── files/
│   │   ├── email/
│   │   ├── bank_statement/
│   │   └── accounting/
│   └── jurisdiction_packs/
│       └── morocco/
├── migrations/
├── tests/
│   ├── unit/
│   ├── integration/
│   ├── workflows/
│   ├── security/
│   ├── evaluations/
│   └── fixtures/
├── infra/
│   ├── docker/
│   ├── terraform/
│   ├── environments/
│   └── observability/
├── docs/
│   ├── architecture.md
│   ├── implementation_spec.md
│   ├── adr/
│   ├── api/
│   ├── security/
│   └── runbooks/
├── scripts/
├── .github/workflows/
├── .env.example
├── docker-compose.yml
├── pyproject.toml
├── package.json
└── README.md
```

## 3.1 Dependency rules

- `domain/*` must not import FastAPI, Temporal SDK, provider SDKs, or frontend code.
- API routes call application services/use cases; they do not contain accounting rules.
- Workflow code coordinates activities; it does not duplicate domain validation.
- Agents call tools through `tool_gateway`; they do not call databases or provider SDKs directly.
- Provider-specific code lives only in adapters.
- Contracts are versioned and may be shared, but must not become a dumping ground for implementation logic.
- Jurisdiction packs provide versioned configuration/rules through a stable interface.
- Frontend features consume API contracts; they do not implement security policy.

## 3.2 Backend module pattern

For each domain module:

```text
domain/<module>/
├── entities.py
├── value_objects.py
├── enums.py
├── commands.py
├── queries.py
├── policies.py
├── repository.py          # Protocol/interface
├── service.py             # Use cases
├── events.py
├── schemas.py
└── tests/
```

Keep persistence adapters separate where practical:

```text
apps/api/avenel_api/infrastructure/
├── db/
├── object_storage/
├── identity/
├── messaging/
└── providers/
```

---

# 4. Database schema — first migration baseline

The SQL below is a starting migration design. Review naming, indexes, retention, and provider-specific types before applying it to production. Use UUIDs for internal identifiers. Store timestamps in UTC (`timestamptz`). Store monetary values as `numeric`, with currency explicitly represented.

## 4.1 Core DDL

```sql
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE tenants (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    legal_name text NOT NULL,
    display_name text,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'suspended', 'closed')),
    default_country_code char(2) NOT NULL DEFAULT 'MA',
    default_currency char(3) NOT NULL DEFAULT 'MAD',
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    identity_subject text NOT NULL UNIQUE,
    email citext NOT NULL UNIQUE,
    full_name text,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('invited', 'active', 'disabled')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    user_id uuid NOT NULL REFERENCES users(id),
    role text NOT NULL,
    permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('invited', 'active', 'revoked')),
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, user_id)
);

CREATE INDEX memberships_user_idx ON memberships(user_id);

CREATE TABLE client_entities (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    legal_name text NOT NULL,
    display_name text,
    country_code char(2) NOT NULL DEFAULT 'MA',
    tax_identifier text,
    registration_identifier text,
    default_currency char(3) NOT NULL DEFAULT 'MAD',
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'inactive', 'archived')),
    accounting_settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, id)
);

CREATE INDEX client_entities_tenant_name_idx
    ON client_entities(tenant_id, legal_name);

CREATE TABLE engagements (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    service_code text NOT NULL,
    scope jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('draft', 'active', 'paused', 'ended')),
    starts_on date,
    ends_on date,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id)
);

CREATE TABLE accounting_periods (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    period_code text NOT NULL,             -- e.g. 2026-09
    starts_on date NOT NULL,
    ends_on date NOT NULL,
    status text NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'processing', 'under_review', 'approved', 'closed')),
    accounting_context_version integer NOT NULL DEFAULT 1,
    jurisdiction_pack_code text NOT NULL DEFAULT 'MA',
    jurisdiction_pack_version text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, client_entity_id, period_code),
    UNIQUE (tenant_id, id),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    CHECK (ends_on >= starts_on)
);

CREATE TABLE work_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    accounting_period_id uuid NOT NULL,
    engagement_id uuid,
    service_code text NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    priority text NOT NULL DEFAULT 'normal'
        CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    requested_by uuid REFERENCES users(id),
    assigned_to uuid REFERENCES users(id),
    due_at timestamptz,
    workflow_definition text NOT NULL,
    workflow_version text NOT NULL,
    workflow_execution_id text,
    completion_summary jsonb,
    submitted_at timestamptz,
    completed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    FOREIGN KEY (tenant_id, accounting_period_id)
        REFERENCES accounting_periods(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE INDEX work_requests_queue_idx
    ON work_requests(tenant_id, status, due_at);

CREATE TABLE documents (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    work_request_id uuid,
    document_type text,
    document_status text NOT NULL DEFAULT 'received'
        CHECK (document_status IN ('received', 'quarantined', 'processing', 'needs_review', 'validated', 'rejected')),
    original_filename text NOT NULL,
    source_channel text NOT NULL DEFAULT 'portal',
    uploaded_by uuid REFERENCES users(id),
    received_at timestamptz NOT NULL DEFAULT now(),
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE document_versions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    document_id uuid NOT NULL,
    version_number integer NOT NULL,
    object_key text NOT NULL,
    sha256 char(64) NOT NULL,
    mime_type text NOT NULL,
    byte_size bigint NOT NULL CHECK (byte_size > 0),
    malware_scan_status text NOT NULL DEFAULT 'pending'
        CHECK (malware_scan_status IN ('pending', 'clean', 'infected', 'error')),
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, document_id)
        REFERENCES documents(tenant_id, id),
    UNIQUE (tenant_id, document_id, version_number),
    UNIQUE (tenant_id, sha256, document_id)
);

CREATE INDEX document_versions_hash_idx
    ON document_versions(tenant_id, sha256);

CREATE TABLE document_extractions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    document_version_id uuid NOT NULL,
    schema_version text NOT NULL,
    provider text NOT NULL,
    model_or_engine text,
    status text NOT NULL CHECK (status IN ('succeeded', 'failed', 'needs_review')),
    extracted_data jsonb NOT NULL,
    field_evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
    confidence_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, document_version_id)
        REFERENCES document_versions(tenant_id, id)
);

CREATE TABLE counterparties (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    counterparty_type text NOT NULL,
    legal_name text NOT NULL,
    identifiers jsonb NOT NULL DEFAULT '{}'::jsonb,
    aliases jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE chart_of_accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    account_code text NOT NULL,
    label text NOT NULL,
    account_type text,
    active boolean NOT NULL DEFAULT true,
    effective_from date,
    effective_to date,
    source text NOT NULL DEFAULT 'customer_configured',
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, client_entity_id, account_code, effective_from)
);

CREATE TABLE tax_codes (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    code text NOT NULL,
    label text NOT NULL,
    treatment jsonb NOT NULL DEFAULT '{}'::jsonb,
    effective_from date,
    effective_to date,
    jurisdiction_pack_version text NOT NULL,
    human_verified boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, client_entity_id, code, effective_from)
);

CREATE TABLE journal_proposals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    accounting_period_id uuid NOT NULL,
    work_request_id uuid NOT NULL,
    currency char(3) NOT NULL,
    status text NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft', 'needs_review', 'submitted', 'approved', 'rejected', 'exported', 'superseded')),
    description text,
    source_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    rule_version text,
    agent_invocation_id uuid,
    created_by_type text NOT NULL DEFAULT 'system',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    FOREIGN KEY (tenant_id, accounting_period_id)
        REFERENCES accounting_periods(tenant_id, id),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE journal_lines (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    journal_proposal_id uuid NOT NULL,
    line_number integer NOT NULL,
    account_code text NOT NULL,
    description text,
    debit numeric(20, 4) NOT NULL DEFAULT 0,
    credit numeric(20, 4) NOT NULL DEFAULT 0,
    currency char(3) NOT NULL,
    tax_code text,
    counterparty_id uuid,
    evidence_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, journal_proposal_id)
        REFERENCES journal_proposals(tenant_id, id),
    CHECK (debit >= 0 AND credit >= 0),
    CHECK (NOT (debit > 0 AND credit > 0)),
    UNIQUE (tenant_id, journal_proposal_id, line_number)
);

CREATE TABLE bank_accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    provider_reference text,
    masked_identifier text,
    currency char(3) NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE bank_transactions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    bank_account_id uuid NOT NULL,
    external_reference text,
    transaction_date date NOT NULL,
    value_date date,
    amount numeric(20, 4) NOT NULL,
    currency char(3) NOT NULL,
    description text,
    normalised_data jsonb NOT NULL DEFAULT '{}'::jsonb,
    source_hash char(64),
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, bank_account_id)
        REFERENCES bank_accounts(tenant_id, id),
    UNIQUE (tenant_id, bank_account_id, external_reference)
);

CREATE TABLE reconciliation_matches (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    bank_transaction_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id uuid NOT NULL,
    match_score numeric(6, 5),
    match_reason jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL DEFAULT 'proposed'
        CHECK (status IN ('proposed', 'accepted', 'rejected', 'superseded')),
    reviewed_by uuid REFERENCES users(id),
    reviewed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, bank_transaction_id)
        REFERENCES bank_transactions(tenant_id, id)
);

CREATE TABLE exceptions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    code text NOT NULL,
    severity text NOT NULL CHECK (severity IN ('info', 'warning', 'high', 'critical')),
    status text NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'assigned', 'waiting_client', 'resolved', 'waived')),
    title text NOT NULL,
    description text,
    evidence_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    assigned_to uuid REFERENCES users(id),
    due_at timestamptz,
    resolution jsonb,
    resolved_by uuid REFERENCES users(id),
    resolved_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id)
);

CREATE TABLE approvals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    resource_type text NOT NULL,
    resource_id uuid NOT NULL,
    action text NOT NULL,
    status text NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
    requested_by_type text NOT NULL,
    requested_by_id text,
    decided_by uuid REFERENCES users(id),
    decision_reason text,
    policy_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    decided_at timestamptz
);

CREATE TABLE workflow_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    engine text NOT NULL,
    engine_execution_id text NOT NULL,
    definition_name text NOT NULL,
    definition_version text NOT NULL,
    state text NOT NULL,
    started_at timestamptz,
    ended_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, id),
    UNIQUE (engine, engine_execution_id)
);

CREATE TABLE agent_invocations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    workflow_record_id uuid NOT NULL,
    task_id text NOT NULL,
    agent_name text NOT NULL,
    agent_version text NOT NULL,
    model_provider text,
    model_name text,
    prompt_version text NOT NULL,
    input_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    output_ref text,
    status text NOT NULL,
    confidence_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
    usage jsonb NOT NULL DEFAULT '{}'::jsonb,
    cost_amount numeric(18, 8),
    started_at timestamptz,
    ended_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, workflow_record_id)
        REFERENCES workflow_records(tenant_id, id)
);

CREATE TABLE evidence_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    subject_type text NOT NULL,
    subject_id uuid NOT NULL,
    evidence_type text NOT NULL,
    source_ref text,
    content_hash char(64),
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id)
);

CREATE TABLE integration_connections (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid,
    provider_code text NOT NULL,
    connection_name text NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    credential_secret_ref text NOT NULL,
    granted_scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
    last_success_at timestamptz,
    last_error jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id)
);

CREATE TABLE export_batches (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    destination_code text NOT NULL,
    payload_object_key text,
    payload_hash char(64),
    idempotency_key text NOT NULL,
    status text NOT NULL DEFAULT 'prepared',
    external_reference text,
    response_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz,
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, idempotency_key)
);

CREATE TABLE usage_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    service_code text NOT NULL,
    unit_code text NOT NULL,
    quantity numeric(18, 4) NOT NULL,
    price_version text NOT NULL,
    billable boolean NOT NULL DEFAULT false,
    billing_status text NOT NULL DEFAULT 'pending',
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id)
);

CREATE TABLE audit_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid,
    actor_type text NOT NULL,
    actor_id text,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id text,
    request_id text,
    correlation_id text,
    event_data jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX audit_events_tenant_time_idx
    ON audit_events(tenant_id, occurred_at DESC);
```

## 4.2 Required schema follow-ups

Before production:
- Enable and test `citext` or replace with normalised email columns.
- Add composite unique constraints and foreign keys consistently to prevent cross-tenant references.
- Add indexes based on measured query plans.
- Add immutable document version and append-only audit permissions/triggers.
- Add explicit document retention and legal-hold fields.
- Add tax-code/account mapping versioning and approval metadata.
- Add currency and decimal scale policies.
- Add tenant RLS policies and test using the real application database role.
- Add database migration tests and rollback strategy.
- Review whether `target_type/target_id` polymorphic references should be replaced with typed foreign keys.
- Do not treat the illustrative SQL as a complete statutory accounting ledger schema.

## 4.3 Row-level security baseline

Example policy pattern; apply to every tenant-owned table and test thoroughly:

```sql
ALTER TABLE client_entities ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_entities FORCE ROW LEVEL SECURITY;

CREATE POLICY client_entities_tenant_policy
ON client_entities
USING (
  tenant_id = current_setting('app.tenant_id', true)::uuid
)
WITH CHECK (
  tenant_id = current_setting('app.tenant_id', true)::uuid
);
```

The application must set `app.tenant_id` inside a transaction after resolving the authenticated user's membership. Use a non-owner application role; table owners and privileged roles can bypass RLS unless configured correctly. RLS is defence in depth, not a replacement for application-level authorisation.

---

# 5. API contracts

## 5.1 API conventions

- Base path: `/v1`.
- JSON request/response bodies; multipart upload or pre-signed upload flow for files.
- UUID internal IDs; public identifiers may be opaque.
- UTC timestamps in ISO 8601.
- Money as decimal strings plus explicit ISO currency code.
- Errors use a stable envelope.
- All authenticated requests have server-resolved tenant context.
- Side-effecting requests support `Idempotency-Key`.
- Every response includes/request propagates `X-Request-ID`.
- Pagination uses cursor-based pagination for large collections.

### Error envelope

```json
{
  "error": {
    "code": "work_request.invalid_state",
    "message": "The work request cannot be submitted from its current state.",
    "details": {
      "current_state": "completed",
      "allowed_states": ["draft"]
    },
    "request_id": "req_..."
  }
}
```

Never return raw stack traces, provider secrets, prompts, or sensitive source data in API errors.

## 5.2 Initial endpoints

| Method | Endpoint | Purpose | Permission |
|---|---|---|---|
| POST | `/v1/client-entities` | Create client entity | `client_entity.create` |
| GET | `/v1/client-entities` | List visible entities | `client_entity.read` |
| GET | `/v1/client-entities/{id}` | Read entity | `client_entity.read` |
| POST | `/v1/accounting-periods` | Create period | `period.create` |
| GET | `/v1/accounting-periods/{id}` | Read period | `period.read` |
| POST | `/v1/work-requests` | Create work request | `work.create` |
| GET | `/v1/work-requests/{id}` | Read work request | `work.read` |
| POST | `/v1/work-requests/{id}/submit` | Submit to workflow | `work.submit` |
| POST | `/v1/work-requests/{id}/documents` | Create upload intent | `document.upload` |
| POST | `/v1/documents/{id}/complete-upload` | Confirm upload | `document.upload` |
| GET | `/v1/documents/{id}` | Read document metadata | `document.read` |
| GET | `/v1/work-requests/{id}/exceptions` | List exceptions | `exception.read` |
| POST | `/v1/exceptions/{id}/resolve` | Resolve exception | `exception.resolve` |
| GET | `/v1/work-requests/{id}/proposals` | List proposals | `proposal.read` |
| POST | `/v1/proposals/{id}/submit-for-review` | Request approval | `approval.request` |
| POST | `/v1/approvals/{id}/decision` | Approve/reject | `approval.decide` |
| POST | `/v1/work-requests/{id}/exports` | Prepare approved export | `export.create` |
| GET | `/v1/exports/{id}` | Export status | `export.read` |
| GET | `/v1/usage` | Usage and billing units | `billing.read` |

## 5.3 Example: create a work request

`POST /v1/work-requests`

```json
{
  "client_entity_id": "0f6f9e35-9c1b-4d83-9d3b-4e0e4f35c9e1",
  "accounting_period_id": "9a8b7c6d-5e4f-3a2b-1c0d-9e8f7a6b5c4d",
  "service_code": "monthly_bookkeeping_preparation",
  "priority": "normal",
  "due_at": "2026-11-10T17:00:00Z"
}
```

Response `201 Created`:

```json
{
  "id": "a5e8c23e-7a9f-4e8d-b9e0-5a6c4f2e1d3b",
  "status": "draft",
  "service_code": "monthly_bookkeeping_preparation",
  "client_entity_id": "0f6f9e35-9c1b-4d83-9d3b-4e0e4f35c9e1",
  "accounting_period_id": "9a8b7c6d-5e4f-3a2b-1c0d-9e8f7a6b5c4d",
  "created_at": "2026-10-30T16:00:00Z"
}
```

The server must verify the caller's membership, access to the client entity, period/entity relationship, service entitlement, and any duplicate active work request policy. The tenant ID is not accepted from the body.

## 5.4 Example: upload protocol

Prefer a two-step upload:
1. `POST /v1/work-requests/{id}/documents` creates a document record and short-lived signed upload URL.
2. Client uploads bytes directly to object storage.
3. `POST /v1/documents/{id}/complete-upload` confirms upload; server verifies object metadata/hash, scans, and starts ingestion.

Upload intent request:

```json
{
  "filename": "supplier-invoice-001.pdf",
  "mime_type": "application/pdf",
  "byte_size": 284193
}
```

Response:

```json
{
  "document_id": "uuid",
  "upload": {
    "method": "PUT",
    "url": "short-lived-signed-url",
    "expires_at": "2026-10-30T16:10:00Z",
    "required_headers": {
      "Content-Type": "application/pdf"
    }
  }
}
```

Never trust the client-reported MIME type or size. Verify server-side and enforce file policy.

## 5.5 Example: approval decision

`POST /v1/approvals/{id}/decision`

```json
{
  "decision": "approved",
  "reason": "Reviewed supporting documents and proposed entries."
}
```

Server checks:
- caller has approval permission for this resource and action;
- approval is pending and not expired/cancelled;
- caller is not the prohibited self-approver for the action;
- required review steps are complete;
- no blocking critical exception remains;
- approval policy snapshot still permits the action;
- decision is recorded immutably.

## 5.6 API schema source of truth

Maintain OpenAPI YAML in `packages/contracts/api/openapi.yaml`. Generate typed clients and server models where practical. Add contract tests to CI. Do not maintain endpoint definitions only in this document.

---

# 6. Workflow definitions and state machine

## 6.1 Workflow identity

Workflow type: `monthly_bookkeeping_preparation`  
Version: `1.0.0`  
One execution per work request revision. Pin:
- work request ID;
- tenant ID resolved by platform;
- client entity ID;
- accounting period ID;
- jurisdiction pack code/version;
- accounting context version;
- workflow definition version;
- integration configuration version.

## 6.2 State machine

```mermaid
stateDiagram-v2
  [*] --> draft
  draft --> submitted
  submitted --> ingesting
  ingesting --> processing
  processing --> awaiting_client_response
  processing --> awaiting_internal_review
  processing --> awaiting_accountant_approval
  processing --> ready_for_export
  awaiting_client_response --> processing
  awaiting_internal_review --> processing
  awaiting_accountant_approval --> processing: rejected / changes requested
  awaiting_accountant_approval --> ready_for_export: approved
  ready_for_export --> exporting
  exporting --> completed
  exporting --> completed_with_exceptions
  submitted --> cancelled
  ingesting --> failed
  processing --> failed
  exporting --> failed
```

State transitions are examples and must be refined during implementation. `failed` should support an audited retry/reprocess action. `completed_with_exceptions` is allowed only where customer policy explicitly permits completion with disclosed non-blocking issues.

## 6.3 Activity sequence

| Order | Activity | Type | Retry | Human gate |
|---:|---|---|---|---|
| 1 | Validate submission and context versions | Deterministic | Limited | No |
| 2 | Enumerate submitted documents | Deterministic | Yes | No |
| 3 | Verify object, malware scan, hash | Deterministic/provider | Yes | Quarantine review if needed |
| 4 | Classify documents | AI + rules | Bounded | Low-confidence |
| 5 | Extract fields | OCR/AI | Bounded | Low-confidence/conflict |
| 6 | Normalise and validate fields | Deterministic | Yes | Invalid/ambiguous |
| 7 | Detect duplicates/related docs | Rules + similarity | Yes | Suspected material duplicate |
| 8 | Resolve counterparty candidates | Rules + AI | Bounded | Ambiguous identity |
| 9 | Propose accounting mapping | AI + approved mappings | Bounded | Unmapped/uncertain treatment |
| 10 | Generate journal proposal | Deterministic assembly | Yes | Always before final approval |
| 11 | Import bank transactions | Connector | Idempotent | Connector errors |
| 12 | Propose reconciliation matches | Rules + AI | Bounded | Ambiguous/material mismatch |
| 13 | Run quality controls | Deterministic | Yes | Critical finding |
| 14 | Create exception/review tasks | Deterministic | Yes | Assigned human |
| 15 | Prepare review package | Deterministic | Yes | No |
| 16 | Accountant approval | Human task | Wait/escalate | Yes |
| 17 | Prepare export | Deterministic | Idempotent | No |
| 18 | Export or produce package | Connector/file | Idempotent | Policy-dependent |
| 19 | Record completion and usage | Deterministic | Idempotent | No |

## 6.4 Workflow invariants

- Never process a quarantined or malware-positive file.
- Never produce a final export while blocking exceptions exist.
- Never export a proposal that is not approved under the current policy.
- Never re-use an approval after the underlying proposal changes.
- Never mutate the source file.
- Never silently replace an accounting-context or jurisdiction version mid-run.
- Every retry is safe and traceable.
- Workflow completion and billable usage creation must be atomic or reconciled through an outbox.
- Human approval tasks must have deadlines/escalation, but never auto-approve on timeout.

---

# 7. Agent contracts and tool catalogue

## 7.1 Agent manifest

Each agent must declare:
- stable name and semantic version;
- purpose and supported task types;
- input/output JSON schema versions;
- approved model families/providers;
- approved tools and scopes;
- max calls, tokens, wall time, and cost;
- confidence/escalation policy;
- prompt/template version;
- evaluation suite and minimum release scores;
- data retention/logging policy;
- owner and last review date.

Example manifest:

```yaml
name: document_extraction
version: 1.0.0
purpose: Extract candidate fields from an approved document version.
input_schema: document-extraction-input.v1
output_schema: document-extraction-output.v1
tools:
  - document.read_scoped
  - extraction.persist_candidate
limits:
  max_model_calls: 4
  max_wall_time_seconds: 90
  max_cost_usd: 0.10
escalation:
  require_review_if:
    - critical_field_confidence_below_threshold
    - conflicting_total_values
    - unsupported_document_type
```

Thresholds and cost limits are configuration examples; calibrate using the evaluation set.

## 7.2 Tool catalogue

| Tool | Read/write | Required scope | Human approval |
|---|---|---|---|
| `document.read_scoped` | Read | `document.read` | No |
| `document.get_ocr_text` | Read | `document.extract` | No |
| `document.persist_extraction` | Write | `document.extraction.write` | No; schema validation |
| `counterparty.search` | Read | `counterparty.read` | No |
| `accounting.get_context` | Read | `accounting.context.read` | No |
| `accounting.propose_journal` | Write proposal | `accounting.proposal.create` | No; proposal only |
| `reconciliation.get_transactions` | Read | `reconciliation.read` | No |
| `reconciliation.propose_match` | Write proposal | `reconciliation.match.propose` | No |
| `exception.create` | Write | `exception.create` | No |
| `client_message.draft` | Write draft | `communication.draft` | No |
| `client_message.send_template` | External side effect | `communication.send_approved` | Policy-controlled |
| `approval.request` | Write request | `approval.request` | No |
| `export.prepare` | Prepare only | `export.prepare` | No |
| `export.execute` | External side effect | `export.execute` | Yes, approved token |

No agent receives `approval.decide`, unrestricted `export.execute`, credential read, arbitrary SQL, arbitrary network, or admin permissions.

## 7.3 Tool execution envelope

```json
{
  "tool_call_id": "uuid",
  "agent_invocation_id": "uuid",
  "tenant_scope": "resolved-by-runtime",
  "resource_scope": ["document:uuid"],
  "tool_name": "accounting.propose_journal",
  "arguments": {},
  "idempotency_key": "stable-key",
  "policy_context": {
    "workflow_id": "uuid",
    "task_id": "uuid",
    "jurisdiction_pack_version": "ma-pack-version"
  }
}
```

Tool gateway must authenticate the agent runtime, resolve tenant/resource scope from trusted context, validate JSON schema, evaluate policy, enforce idempotency, execute the narrow operation, and append an audit event. Never trust the model to provide its own tenant identity or permission scope.

## 7.4 Prompt and retrieval rules

- System policy and tool permissions are outside retrieved content.
- Treat all document text, email text, web content, and user-supplied files as untrusted.
- Retrieved context is data, not instructions.
- Provide only minimum necessary context for a task.
- Do not expose one client's context to another client or tenant.
- Prompts contain schemas and explicit abstention/escalation instructions.
- Model outputs are candidates; deterministic validators decide whether they are structurally and financially valid.
- Store prompt version and model metadata, not unnecessary copies of sensitive content.

---

# 8. Accounting proposal and reconciliation rules

## 8.1 Journal proposal validation

Before a proposal can be submitted for approval:
- each line has an account code valid for the client entity and effective period;
- each line has non-negative debit and credit;
- no line has both debit and credit greater than zero;
- all lines use the proposal currency unless explicit multi-currency handling exists;
- debit total equals credit total within an explicitly configured rounding policy;
- all required source evidence references resolve;
- tax code is valid for the effective period or explicitly marked for human review;
- proposal period is open and belongs to the client entity;
- no duplicate active proposal exists for the same source/event without an explicit revision relationship.

Do not invent Moroccan accounting mappings or tax treatment. A customer-approved chart and reviewed jurisdiction pack supply them.

## 8.2 Reconciliation proposal

Candidate scoring can consider:
- amount equality or approved tolerance;
- currency;
- transaction and document dates;
- counterparty identity;
- invoice/reference number;
- description similarity;
- prior approved matching patterns.

The score is a prioritisation signal, not proof. Acceptance thresholds must be calibrated per customer and task. High-value, ambiguous, split, partial, or multi-document matches require review unless a customer-approved policy explicitly allows otherwise.

## 8.3 Duplicate detection

Use exact file hash for byte-identical duplicates, plus metadata and similarity signals for near-duplicates. Do not automatically discard near-duplicates: a corrected invoice, credit note, or revised statement may be legitimate. Keep the source and create a duplicate/related-document finding for review.

---

# 9. Security implementation checklist

## 9.1 Authentication and authorisation
- OIDC login; validate issuer, audience, signature, expiry, and nonce.
- MFA required for tenant owners, approval-capable users, platform operators.
- Resolve tenant membership server-side on every request.
- Check action permission and resource relationship, not just role string.
- Deny by default.
- Use service identities for workers and connectors.
- Revoke sessions and tokens on membership disablement.

## 9.2 File handling
- Allow-list extensions and MIME types.
- Enforce maximum bytes, page count, and decompression limits.
- Detect actual content type; do not trust filename.
- Malware scan and quarantine.
- Random object keys; no user-controlled storage paths.
- Short-lived signed URLs, scoped to one object and operation.
- Prevent public bucket access.
- Record checksum and immutable version metadata.

## 9.3 AI security
- Tool allowlist per agent and task.
- No arbitrary shell, database, browser, or network tools.
- Prompt-injection tests in golden evaluation.
- Model provider data terms reviewed.
- Redact unnecessary personal/financial identifiers before provider calls where feasible.
- Budget, timeout, and concurrency limits.
- Human approval for high-impact actions.
- No secrets in prompts, traces, or agent context.

## 9.4 Operational security
- Separate dev/staging/prod credentials.
- Secrets manager and rotation.
- Dependency/container/SAST scanning.
- Database backups and restore drills.
- Production access approval and audit.
- Incident response runbook and breach escalation.
- Periodic tenant-isolation penetration tests.

---

# 10. Test plan and release gates

## 10.1 Minimum automated tests

**Unit**
- Decimal and balancing rules.
- Date/period validation.
- Permission policies.
- Workflow state transitions.
- Idempotency key behaviour.
- Duplicate detection.
- Tax/account mapping effective dates.

**Integration**
- PostgreSQL migrations and RLS.
- Object storage upload and signed URL expiry.
- Malware scanner adapter.
- OCR adapter contract.
- Model gateway schema enforcement.
- Workflow engine retry/recovery.
- Connector idempotency.

**Security**
- User from Tenant A cannot enumerate/read Tenant B resources.
- Forged tenant ID in body/header has no effect.
- Client user cannot access another client entity within same firm.
- Revoked membership loses access.
- Agent cannot invoke unlisted tool.
- Prompt injection cannot increase permissions.
- Quarantined document cannot enter extraction workflow.
- Expired approval cannot authorise export.

**Workflow**
- Happy path from upload through approved export.
- Missing document causes client request and resumes safely.
- OCR failure retries and preserves source.
- Model invalid output escalates.
- Accountant rejects proposal; revision is created.
- Worker restarts without duplicate export.
- Integration revoked mid-run blocks safely.
- Workflow cancellation preserves evidence.

## 10.2 Golden evaluation set

Build a permissioned dataset including:
- clean and low-quality scans;
- varied invoice/receipt layouts;
- Arabic, French, and other languages actually present in pilot documents;
- duplicates, near-duplicates, credit notes;
- missing/conflicting totals and dates;
- unusual currencies and date formats;
- ambiguous bank descriptions;
- prompt-injection text in a document;
- accountant-labelled account mappings and match outcomes.

For each case record expected fields, evidence location, acceptable alternatives, reviewer, label version, and known ambiguity. Use synthetic/anonymised data when possible and confirm lawful basis for any real customer records.

## 10.3 Release gates

A release is blocked unless:
- migrations and rollback plan pass;
- unit, integration, contract, workflow, and security tests pass;
- tenant isolation suite passes;
- critical AI evaluation thresholds pass;
- no critical open vulnerability;
- monitoring and alerting are active;
- backup/restore procedure is tested;
- human review and rollback path work;
- cost/latency budgets are met;
- accountable product and accounting reviewers sign off.

---

# 11. Engineering backlog

Priority definitions:
- **P0:** required before any pilot with real customer data.
- **P1:** required for the first end-to-end pilot.
- **P2:** required for paid repeatability and commercial operations.
- **P3:** post-MVP expansion.

Each ticket below should become a GitHub issue with owner, estimate, dependencies, and linked acceptance tests.

## EPIC A — Project foundation

### AVN-001 — Initialise monorepo [P0]
**Scope:** Create repository, package boundaries, Python/TypeScript tooling, linting, formatting, pre-commit, CI skeleton.  
**Acceptance criteria:**
- API, web, worker packages build locally.
- Lint, type-check, and unit-test commands run in CI.
- `.env.example` documents required non-secret settings.
- No secrets committed.
- README contains local setup instructions.

### AVN-002 — Containerised local environment [P0]
**Scope:** Docker Compose for PostgreSQL, object-storage emulator if selected, workflow engine, API, worker, web.  
**Acceptance criteria:**
- One documented command starts dependencies.
- Health checks exist.
- Persistent local volumes are documented.
- Test data is synthetic.
- No production credentials required.

### AVN-003 — CI quality and security gates [P0]
**Scope:** Unit tests, type checks, dependency scanning, secret scanning, container scan.  
**Acceptance criteria:**
- Pull requests run required checks.
- Critical security findings fail the build.
- Dependency lockfiles are committed.
- Build artefacts are reproducible.

## EPIC B — Identity, tenancy, and access

### AVN-010 — OIDC authentication [P0]
**Acceptance criteria:**
- Login/logout and token validation work.
- Issuer, audience, signature, expiry are validated.
- Disabled user cannot access protected routes.
- Authentication events are audited.

### AVN-011 — Tenant and membership domain [P0]
**Acceptance criteria:**
- Tenant creation and user membership are persisted.
- User can belong to multiple tenants only through explicit memberships.
- Tenant context is resolved server-side.
- Tenant switching revalidates membership.

### AVN-012 — RBAC and resource authorisation [P0]
**Acceptance criteria:**
- Permission checks are centralised.
- Resource access checks include tenant and client-entity relationship.
- Default is deny.
- Tests cover owner, manager, accountant, staff, client user, and ops.

### AVN-013 — PostgreSQL RLS [P0]
**Acceptance criteria:**
- RLS enabled on all tenant-owned tables.
- Application role cannot bypass RLS.
- Tenant context is transaction-scoped.
- Cross-tenant integration tests pass.

### AVN-014 — Audit events [P0]
**Acceptance criteria:**
- Authentication, membership, document, approval, export, and support-access events are recorded.
- Events include actor, tenant, action, resource, request/correlation IDs, timestamp.
- Sensitive document content and secrets are excluded.
- Ordinary application role cannot update/delete audit rows.

## EPIC C — Client and work management

### AVN-020 — Client entity CRUD [P0]
**Acceptance criteria:**
- Firm-authorised users can create/read/update/archive client entities.
- Required identifiers are validated without imposing unverified jurisdiction rules.
- Every query is tenant-scoped.
- Client entity changes are audited.

### AVN-021 — Accounting period management [P0]
**Acceptance criteria:**
- Period has start/end dates, status, jurisdiction pack version, accounting-context version.
- Period must belong to selected client entity.
- Overlapping-period policy is explicit/configurable.
- Closed periods cannot receive new work without authorised reopen action.

### AVN-022 — Work request lifecycle [P0]
**Acceptance criteria:**
- Create work request against valid client entity and period.
- Allowed state transitions are enforced.
- Workflow definition/version is pinned.
- Duplicate active work policy is implemented.
- Work timeline is queryable.

### AVN-023 — Firm dashboard and work queue [P1]
**Acceptance criteria:**
- Shows active, blocked, overdue, and completed work.
- Filters by client, period, assignee, state, priority.
- Users see only authorised tenant/client scope.
- Queue metrics match backend state.

## EPIC D — Secure document intake

### AVN-030 — Upload intent API [P0]
**Acceptance criteria:**
- Creates tenant-scoped document and short-lived signed upload URL.
- Validates allowed file types and configured size limits.
- Storage key is random and server-generated.
- Upload intent expires.

### AVN-031 — Upload completion and malware scan [P0]
**Acceptance criteria:**
- Server verifies object exists, size, checksum, and actual content type.
- Malware scan status is recorded.
- Infected/unknown files are quarantined.
- Quarantined files cannot enter OCR or agent processing.

### AVN-032 — Immutable document versions [P0]
**Acceptance criteria:**
- Original bytes are never overwritten.
- Every version stores hash, size, MIME, uploader, timestamp, object key.
- Duplicate hash is detected within tenant scope.
- Access is audited.

### AVN-033 — Document register UI [P1]
**Acceptance criteria:**
- Firm user sees permitted document list and processing state.
- Client user sees only their own permitted documents.
- Download links are short-lived.
- Quarantine details are not exposed unnecessarily.

## EPIC E — Document intelligence

### AVN-040 — OCR provider interface [P1]
**Acceptance criteria:**
- Provider adapter has typed input/output.
- Provider can be swapped without changing domain contract.
- Timeouts, retries, and provider errors are normalised.
- Provider data terms and retention are documented before live use.

### AVN-041 — Extraction schema and evidence locations [P1]
**Acceptance criteria:**
- Invoice/receipt extraction schema is versioned.
- Fields support value, normalised value, confidence, source page/region, and warnings.
- Unknown fields are preserved safely or rejected according to schema policy.
- Extraction result links to immutable document version.

### AVN-042 — Classification and deterministic validation [P1]
**Acceptance criteria:**
- Document class is a candidate with confidence and evidence.
- Required-field validation is deterministic.
- Unsupported/ambiguous document type creates review task.
- No model output is treated as validated solely because it parses.

### AVN-043 — Duplicate and related-document detection [P1]
**Acceptance criteria:**
- Exact hash duplicates are detected.
- Near-duplicate signals are recorded with explanation.
- Credit notes/revisions are not automatically discarded.
- Human review can mark related, duplicate, or distinct.

## EPIC F — Accounting preparation

### AVN-050 — Customer chart-of-accounts configuration [P1]
**Acceptance criteria:**
- Accounts are scoped to client entity.
- Effective dates and active status are supported.
- Import/export format is documented.
- No unverified Moroccan default mapping is silently applied.

### AVN-051 — Accounting context versioning [P1]
**Acceptance criteria:**
- Customer policies/mappings are versioned.
- Workflow pins the version it uses.
- Changes create a new version and audit event.
- Existing approved proposals retain original context reference.

### AVN-052 — Journal proposal domain [P1]
**Acceptance criteria:**
- Proposals and lines are stored separately.
- Decimal values are used.
- Source evidence references are mandatory for material lines.
- Proposal status transitions are enforced.
- Balanced-entry validator is deterministic.

### AVN-053 — Bookkeeping preparation agent [P1]
**Acceptance criteria:**
- Agent can only read scoped evidence/context and create proposals.
- Output conforms to schema.
- Unknown account/tax treatment escalates.
- It cannot approve or export.
- Evaluation results are recorded by version.

## EPIC G — Bank import and reconciliation

### AVN-060 — Bank statement import [P1]
**Acceptance criteria:**
- At least one documented CSV/XLSX format is supported.
- Imported rows are normalised to canonical schema.
- Original file and import batch are preserved.
- Duplicate import detection is idempotent.

### AVN-061 — Reconciliation candidate engine [P1]
**Acceptance criteria:**
- Candidate match features and score are recorded.
- No candidate is silently accepted below approved threshold.
- Ambiguous/material matches create review task.
- Accepted/rejected decisions are auditable.

### AVN-062 — Reconciliation review UI [P1]
**Acceptance criteria:**
- Reviewer sees bank transaction, candidate, evidence, score explanation, and alternatives.
- Accept/reject requires permission.
- Decision updates workflow state safely.
- Reprocessing does not erase prior decision history.

## EPIC H — Workflow and orchestration

### AVN-070 — Durable workflow engine integration [P0]
**Acceptance criteria:**
- Workflow can start, persist, resume after worker restart.
- Workflow execution ID maps to work request.
- Workflow definition version is pinned.
- Correlation IDs propagate.

### AVN-071 — Monthly bookkeeping workflow v1 [P1]
**Acceptance criteria:**
- Activities follow documented order.
- Retry policies are bounded.
- Human wait states persist.
- Failed steps can be retried safely.
- Workflow cannot complete with blocking exception.

### AVN-072 — Exception and human task service [P1]
**Acceptance criteria:**
- Exception has code, severity, owner, due date, evidence, status.
- Review task is assignable.
- Client-response wait state can resume workflow.
- Escalation is recorded.

### AVN-073 — Workflow recovery and replay [P1]
**Acceptance criteria:**
- Operations user can inspect stuck execution.
- Retry/replay is permissioned and audited.
- Side effects are idempotent.
- Reprocessing creates new revision/execution where appropriate.

## EPIC I — Human approval and exports

### AVN-080 — Approval policy engine [P0]
**Acceptance criteria:**
- Approval requirements are evaluated by action, tenant, role, amount/materiality, and resource state.
- Policy snapshot is stored with request.
- Self-approval restrictions are supported.
- Deny is default.

### AVN-081 — Accountant review UI [P1]
**Acceptance criteria:**
- Shows proposals, source evidence, deterministic checks, exceptions, and version information.
- Reviewer can approve/reject/request changes with reason.
- No approve button is shown to unauthorised users.
- Approval is immutable and tied to exact proposal version.

### AVN-082 — Export package generation [P1]
**Acceptance criteria:**
- Export only includes approved proposals.
- Package contains agreed structured data and evidence manifest.
- Payload hash is stored.
- Export can be downloaded securely.
- Export status and version are visible.

### AVN-083 — First accounting-system connector [P2]
**Acceptance criteria:**
- Connector selected from pilot-firm evidence.
- Capability discovery and auth scopes documented.
- Export is idempotent.
- External response is reconciled and stored.
- Manual package export remains fallback.

## EPIC J — Agent and model governance

### AVN-090 — Model gateway [P1]
**Acceptance criteria:**
- Provider interface is stable.
- Model calls have timeout, budget, and cost metadata.
- Sensitive content is minimised.
- Provider errors are normalised.
- Model selection is configuration-controlled.

### AVN-091 — Tool gateway [P0]
**Acceptance criteria:**
- Agent identity and allowed tool scopes are verified.
- Tool input/output schema validation is enforced.
- Tenant/resource context is runtime-supplied.
- Idempotency and audit are implemented.
- No arbitrary SQL/network/shell capability exists.

### AVN-092 — Agent registry and versioning [P1]
**Acceptance criteria:**
- Agent manifest stores version, schemas, tools, limits, prompt version, owner.
- Invocation links to exact agent version.
- Deprecated versions cannot be newly scheduled.
- Rollback is supported.

### AVN-093 — Evaluation harness [P1]
**Acceptance criteria:**
- Golden datasets and expected labels are versioned.
- Evaluations run on pull request or model promotion.
- Metrics include quality, escalation, latency, and cost.
- Failed critical threshold blocks promotion.

## EPIC K — Billing and operations

### AVN-100 — Usage event generation [P2]
**Acceptance criteria:**
- Usage is generated only from verified completion state.
- Idempotent unique reference per billable unit.
- Failed/incomplete workflow is not billed by default.
- Price version is recorded.

### AVN-101 — Billing and usage dashboard [P2]
**Acceptance criteria:**
- Firm owner can view units, status, and price version.
- Internal ops can compare cost and revenue per workflow.
- Sensitive accounting content is not exposed in billing view.

### AVN-102 — Observability and alerts [P0]
**Acceptance criteria:**
- API, workflow, agent, and connector traces share correlation ID.
- Alerts cover API failures, stuck workflows, queue backlog, provider outage, and security events.
- Logs are structured and redacted.
- Dashboards show technical and workflow health.

### AVN-103 — Backup and restore drills [P0]
**Acceptance criteria:**
- Database and object storage backup policy is documented.
- Restore is tested in isolated environment.
- Recovery procedure and responsible owner are documented.
- Restore result is recorded.

### AVN-104 — Incident response runbook [P0]
**Acceptance criteria:**
- Security incident severity levels defined.
- Containment, evidence preservation, escalation, and customer communication owners identified.
- Data breach/legal notification process reviewed with counsel.
- Tabletop exercise completed before broad production launch.

---

# 12. Recommended sprint sequence

A sprint is assumed to be two weeks; adjust for team size. Do not promise dates until staffing and estimates are known.

| Sprint | Main objective | Tickets |
|---|---|---|
| 0 | Repo and engineering foundation | AVN-001, 002, 003 |
| 1 | Identity and tenant boundaries | AVN-010, 011, 012, 014 |
| 2 | RLS and client/work models | AVN-013, 020, 021, 022 |
| 3 | Secure document intake | AVN-030, 031, 032 |
| 4 | Durable workflow and observability | AVN-070, 071 foundation, 102 |
| 5 | OCR/extraction pipeline | AVN-040, 041, 042 |
| 6 | Accounting context and proposals | AVN-050, 051, 052 |
| 7 | Agent/tool governance | AVN-091, 090, 092, 053 |
| 8 | Bank import and reconciliation | AVN-060, 061, 062 |
| 9 | Exceptions and approval | AVN-072, 080, 081 |
| 10 | Evidence export and pilot hardening | AVN-082, 073, 103, 104 |
| 11 | Pilot metrics and commercial readiness | AVN-100, 101, 093 |

This is a dependency-oriented sequence, not a commitment to complete all tickets in 22 weeks. A small team may need more time; parallel work requires clear ownership and stable contracts.

---

# 13. Definition of pilot readiness

Do not onboard live customer records until all P0 items and the relevant P1 workflow path are complete.

**Product**
- One service definition and workflow scope agreed with pilot firm.
- Baseline processing time and error/rework data measured.
- Firm and client user journeys tested.

**Accounting**
- Customer chart-of-accounts context configured and reviewed.
- Accountant has validated the proposal format and review procedure.
- All tax/accounting uncertainties route to a qualified reviewer.
- No autonomous filing, payment, or unapproved posting.

**Security/privacy**
- Tenant isolation and role tests pass.
- Data processing terms, provider subprocessors, retention, hosting, and transfer questions reviewed.
- Upload scanning, encryption, access logs, backups, and incident process operational.
- Legal basis and customer permissions documented.

**Operations**
- Stuck workflow and provider outage runbooks tested.
- Human review staffing and escalation are defined.
- Quality sampling and customer support ownership defined.
- Cost per file is measured.

**Commercial**
- Pilot price and billable completion definition agreed.
- Contract defines scope, exclusions, responsibilities, and service limits.
- Customer success metrics agreed.

---

# 14. Items requiring accountant, customer, or legal sign-off

| Item | Required reviewer | Why |
|---|---|---|
| Chart-of-accounts mappings | Customer accountant | Firm/client-specific |
| Tax code and treatment | Qualified local accountant/tax specialist | Jurisdiction/year-specific |
| Journal proposal format | Pilot accountant | Must fit real operating workflow |
| Materiality thresholds | Firm owner/accountant | Risk and responsibility |
| Approval matrix | Firm owner and professional lead | Authority and separation of duties |
| Accounting-system export | Pilot firm and vendor docs | Format and integration correctness |
| Data retention | Legal/privacy adviser + customer | Contractual and legal obligations |
| Hosting and international transfers | Legal/privacy adviser | Data protection obligations |
| AI/OCR provider terms | Legal/privacy/security | Processing, retention, training, location |
| Service scope and claims | Legal/commercial adviser | Avoid representing unqualified regulated service |

---

# 15. Final engineering rule

The MVP is not “an AI that reads invoices.” It is a secure, tenant-isolated, durable financial workflow that can take a permissioned file from intake to accountant-approved deliverable, with evidence, exception handling, recovery, and measured unit economics.

**Build the workflow and controls first. Add agent autonomy only where evaluation proves it is safe, useful, and economically better.**
