-- AVENEL initial schema baseline. Review before production use.
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS citext;

CREATE TABLE tenants (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    legal_name text NOT NULL,
    display_name text,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'suspended', 'closed')),
    default_country_code char(2) NOT NULL DEFAULT 'MA',
    default_currency char(3) NOT NULL DEFAULT 'MAD',
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    identity_subject text NOT NULL UNIQUE,
    email citext NOT NULL UNIQUE,
    full_name text,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('invited', 'active', 'disabled')),
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE memberships (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    user_id uuid NOT NULL REFERENCES users(id),
    role text NOT NULL,
    permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('invited', 'active', 'revoked')),
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, user_id)
);

CREATE INDEX memberships_user_idx ON memberships(user_id);

CREATE TABLE client_entities (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    legal_name text NOT NULL,
    display_name text,
    country_code char(2) NOT NULL DEFAULT 'MA',
    tax_identifier text,
    registration_identifier text,
    default_currency char(3) NOT NULL DEFAULT 'MAD',
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'inactive', 'archived')),
    accounting_settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, id)
);

CREATE INDEX client_entities_tenant_name_idx
    ON client_entities(tenant_id, legal_name);

CREATE TABLE engagements (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    service_code text NOT NULL,
    scope jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL DEFAULT 'active'
        CHECK (status IN ('draft', 'active', 'paused', 'ended')),
    starts_on date,
    ends_on date,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id)
);

CREATE TABLE accounting_periods (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    period_code text NOT NULL,             -- e.g. 2026-09
    starts_on date NOT NULL,
    ends_on date NOT NULL,
    status text NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'processing', 'under_review', 'approved', 'closed')),
    accounting_context_version integer NOT NULL DEFAULT 1,
    jurisdiction_pack_code text NOT NULL DEFAULT 'MA',
    jurisdiction_pack_version text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    UNIQUE (tenant_id, client_entity_id, period_code),
    UNIQUE (tenant_id, id),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    CHECK (ends_on >= starts_on)
);

CREATE TABLE work_requests (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    accounting_period_id uuid NOT NULL,
    engagement_id uuid,
    service_code text NOT NULL,
    status text NOT NULL DEFAULT 'draft',
    priority text NOT NULL DEFAULT 'normal'
        CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    requested_by uuid REFERENCES users(id),
    assigned_to uuid REFERENCES users(id),
    due_at timestamptz,
    workflow_definition text NOT NULL,
    workflow_version text NOT NULL,
    workflow_execution_id text,
    completion_summary jsonb,
    submitted_at timestamptz,
    completed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    FOREIGN KEY (tenant_id, accounting_period_id)
        REFERENCES accounting_periods(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE INDEX work_requests_queue_idx
    ON work_requests(tenant_id, status, due_at);

CREATE TABLE documents (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    work_request_id uuid,
    document_type text,
    document_status text NOT NULL DEFAULT 'received'
        CHECK (document_status IN ('received', 'quarantined', 'processing', 'needs_review', 'validated', 'rejected')),
    original_filename text NOT NULL,
    source_channel text NOT NULL DEFAULT 'portal',
    uploaded_by uuid REFERENCES users(id),
    received_at timestamptz NOT NULL DEFAULT now(),
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE document_versions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    document_id uuid NOT NULL,
    version_number integer NOT NULL,
    object_key text NOT NULL,
    sha256 char(64) NOT NULL,
    mime_type text NOT NULL,
    byte_size bigint NOT NULL CHECK (byte_size > 0),
    malware_scan_status text NOT NULL DEFAULT 'pending'
        CHECK (malware_scan_status IN ('pending', 'clean', 'infected', 'error')),
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, document_id)
        REFERENCES documents(tenant_id, id),
    UNIQUE (tenant_id, document_id, version_number),
    UNIQUE (tenant_id, sha256, document_id)
);

CREATE INDEX document_versions_hash_idx
    ON document_versions(tenant_id, sha256);

CREATE TABLE document_extractions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    document_version_id uuid NOT NULL,
    schema_version text NOT NULL,
    provider text NOT NULL,
    model_or_engine text,
    status text NOT NULL CHECK (status IN ('succeeded', 'failed', 'needs_review')),
    extracted_data jsonb NOT NULL,
    field_evidence jsonb NOT NULL DEFAULT '{}'::jsonb,
    confidence_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, document_version_id)
        REFERENCES document_versions(tenant_id, id)
);

CREATE TABLE counterparties (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    counterparty_type text NOT NULL,
    legal_name text NOT NULL,
    identifiers jsonb NOT NULL DEFAULT '{}'::jsonb,
    aliases jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE chart_of_accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    account_code text NOT NULL,
    label text NOT NULL,
    account_type text,
    active boolean NOT NULL DEFAULT true,
    effective_from date,
    effective_to date,
    source text NOT NULL DEFAULT 'customer_configured',
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, client_entity_id, account_code, effective_from)
);

CREATE TABLE tax_codes (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    code text NOT NULL,
    label text NOT NULL,
    treatment jsonb NOT NULL DEFAULT '{}'::jsonb,
    effective_from date,
    effective_to date,
    jurisdiction_pack_version text NOT NULL,
    human_verified boolean NOT NULL DEFAULT false,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, client_entity_id, code, effective_from)
);

CREATE TABLE journal_proposals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    accounting_period_id uuid NOT NULL,
    work_request_id uuid NOT NULL,
    currency char(3) NOT NULL,
    status text NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft', 'needs_review', 'submitted', 'approved', 'rejected', 'exported', 'superseded')),
    description text,
    source_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    rule_version text,
    agent_invocation_id uuid,
    created_by_type text NOT NULL DEFAULT 'system',
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    FOREIGN KEY (tenant_id, accounting_period_id)
        REFERENCES accounting_periods(tenant_id, id),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE journal_lines (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    journal_proposal_id uuid NOT NULL,
    line_number integer NOT NULL,
    account_code text NOT NULL,
    description text,
    debit numeric(20, 4) NOT NULL DEFAULT 0,
    credit numeric(20, 4) NOT NULL DEFAULT 0,
    currency char(3) NOT NULL,
    tax_code text,
    counterparty_id uuid,
    evidence_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, journal_proposal_id)
        REFERENCES journal_proposals(tenant_id, id),
    CHECK (debit >= 0 AND credit >= 0),
    CHECK (NOT (debit > 0 AND credit > 0)),
    UNIQUE (tenant_id, journal_proposal_id, line_number)
);

CREATE TABLE bank_accounts (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid NOT NULL,
    provider_reference text,
    masked_identifier text,
    currency char(3) NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id),
    UNIQUE (tenant_id, id)
);

CREATE TABLE bank_transactions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    bank_account_id uuid NOT NULL,
    external_reference text,
    transaction_date date NOT NULL,
    value_date date,
    amount numeric(20, 4) NOT NULL,
    currency char(3) NOT NULL,
    description text,
    normalised_data jsonb NOT NULL DEFAULT '{}'::jsonb,
    source_hash char(64),
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, bank_account_id)
        REFERENCES bank_accounts(tenant_id, id),
    UNIQUE (tenant_id, bank_account_id, external_reference)
);

CREATE TABLE reconciliation_matches (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    bank_transaction_id uuid NOT NULL,
    target_type text NOT NULL,
    target_id uuid NOT NULL,
    match_score numeric(6, 5),
    match_reason jsonb NOT NULL DEFAULT '{}'::jsonb,
    status text NOT NULL DEFAULT 'proposed'
        CHECK (status IN ('proposed', 'accepted', 'rejected', 'superseded')),
    reviewed_by uuid REFERENCES users(id),
    reviewed_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, bank_transaction_id)
        REFERENCES bank_transactions(tenant_id, id)
);

CREATE TABLE exceptions (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    code text NOT NULL,
    severity text NOT NULL CHECK (severity IN ('info', 'warning', 'high', 'critical')),
    status text NOT NULL DEFAULT 'open'
        CHECK (status IN ('open', 'assigned', 'waiting_client', 'resolved', 'waived')),
    title text NOT NULL,
    description text,
    evidence_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    assigned_to uuid REFERENCES users(id),
    due_at timestamptz,
    resolution jsonb,
    resolved_by uuid REFERENCES users(id),
    resolved_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id)
);

CREATE TABLE approvals (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    resource_type text NOT NULL,
    resource_id uuid NOT NULL,
    action text NOT NULL,
    status text NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'approved', 'rejected', 'cancelled')),
    requested_by_type text NOT NULL,
    requested_by_id text,
    decided_by uuid REFERENCES users(id),
    decision_reason text,
    policy_snapshot jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    decided_at timestamptz
);

CREATE TABLE workflow_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    engine text NOT NULL,
    engine_execution_id text NOT NULL,
    definition_name text NOT NULL,
    definition_version text NOT NULL,
    state text NOT NULL,
    started_at timestamptz,
    ended_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, id),
    UNIQUE (engine, engine_execution_id)
);

CREATE TABLE agent_invocations (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    workflow_record_id uuid NOT NULL,
    task_id text NOT NULL,
    agent_name text NOT NULL,
    agent_version text NOT NULL,
    model_provider text,
    model_name text,
    prompt_version text NOT NULL,
    input_refs jsonb NOT NULL DEFAULT '[]'::jsonb,
    output_ref text,
    status text NOT NULL,
    confidence_summary jsonb NOT NULL DEFAULT '{}'::jsonb,
    usage jsonb NOT NULL DEFAULT '{}'::jsonb,
    cost_amount numeric(18, 8),
    started_at timestamptz,
    ended_at timestamptz,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, workflow_record_id)
        REFERENCES workflow_records(tenant_id, id)
);

CREATE TABLE evidence_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    subject_type text NOT NULL,
    subject_id uuid NOT NULL,
    evidence_type text NOT NULL,
    source_ref text,
    content_hash char(64),
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id)
);

CREATE TABLE integration_connections (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    client_entity_id uuid,
    provider_code text NOT NULL,
    connection_name text NOT NULL,
    status text NOT NULL DEFAULT 'pending',
    credential_secret_ref text NOT NULL,
    granted_scopes jsonb NOT NULL DEFAULT '[]'::jsonb,
    last_success_at timestamptz,
    last_error jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, client_entity_id)
        REFERENCES client_entities(tenant_id, id)
);

CREATE TABLE export_batches (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    destination_code text NOT NULL,
    payload_object_key text,
    payload_hash char(64),
    idempotency_key text NOT NULL,
    status text NOT NULL DEFAULT 'prepared',
    external_reference text,
    response_metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    completed_at timestamptz,
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id),
    UNIQUE (tenant_id, idempotency_key)
);

CREATE TABLE usage_records (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid NOT NULL REFERENCES tenants(id),
    work_request_id uuid NOT NULL,
    service_code text NOT NULL,
    unit_code text NOT NULL,
    quantity numeric(18, 4) NOT NULL,
    price_version text NOT NULL,
    billable boolean NOT NULL DEFAULT false,
    billing_status text NOT NULL DEFAULT 'pending',
    metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    FOREIGN KEY (tenant_id, work_request_id)
        REFERENCES work_requests(tenant_id, id)
);

CREATE TABLE audit_events (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id uuid,
    actor_type text NOT NULL,
    actor_id text,
    action text NOT NULL,
    resource_type text NOT NULL,
    resource_id text,
    request_id text,
    correlation_id text,
    event_data jsonb NOT NULL DEFAULT '{}'::jsonb,
    occurred_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX audit_events_tenant_time_idx
    ON audit_events(tenant_id, occurred_at DESC);
